@php
    error_reporting(0);
@endphp
@extends('layouts.master')

@section('content')



<div class="row justify-content-center">
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12" style="">
                <div class="card" >
                    <div class="card-body">
                        <h4>Profile Page</h4>
                        <hr>
                        <form method="POST" action="/profile">
                            @csrf

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
    <label for="">Name</label>
    <input type="text" value="{{Auth::user()->username}}" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
    <label for="">Email</label>
    <input type="text" value="{{Auth::user()->email}}" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
    <label for="">Password</label>
    <input type="text" value="{{Auth::user()->password}}" class="form-control">
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="">Image</label>
                                        <img src="{{asset('img/'.Auth::user()->image)}}" class="pic">
                                    </div>
                                </div>

                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-success">
                                        {{ __('Update') }}
                                    </button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
    </section>

@endsection



