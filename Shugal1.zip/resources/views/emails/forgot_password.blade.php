@component('mail::message')
# Your Verification Code

{{$code}}

Thanks,<br>
{{ config('app.name') }}
@endcomponent
