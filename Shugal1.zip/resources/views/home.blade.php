
@php
    error_reporting(0);
@endphp
@extends('layouts.master')

@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    You are logged in!
                </div>
            </div>
        </div>
    </div>

<div class="card-body">
    <form action="/profile" method="POST">
        @csrf

        <div class="input-group form-group">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-user"></i></span>
            </div>
            <input type="text" name="body" class="form-control" placeholder="body">

        </div>


        <div class="form-group">
            <input type="submit" value="Create" class="btn float-right login_btn">
        </div>
    </form>
</div>

</div>
@endsection
