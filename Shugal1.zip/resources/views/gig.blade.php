

@php
error_reporting(0);
@endphp

@extends('layouts.master')

@section('content')

<div class="row">
<div class="col-md-8 offset-2">

{!! Form::open(['action'=> ['PostController', $user->id], 'method'=> 'POST', 'files'=>true]) !!}
@csrf

<div class="form-group">

{{Form::label('title', 'Title:')}}
{{Form::text('title', '',['class'=>'form-control', 'placeholder'=>'Title of the Post']) }}


    {{Form::label('category', 'Category:')}}
    div class="categories"></div>
    <a href="#">Categories</a>
    <div class="kp-menu-container">

{{Form::label('category', 'Category:')}}
    div class="categories"></div>
    <a href="#">Categories</a>
    <div class="kp-menu-container">

{{Form::text('title', '',['class'=>'form-control', 'placeholder'=>'Title of the Post']) }}

















<div class="container">
    <div class="row">
        <div class="col-md-8 offset-2">
            <div class="card mt-5">
                <div class="card-header">
                    Category Subcategory Dropdown in PHP MySQL Ajax
                </div>
                <div class="card-body">
                    <form>
                        <div class="form-group">
                            <label for="CATEGORY-DROPDOWN">Category</label>
                            <select class="form-control" id="category-dropdown">
                                <option value="">Select Category</option>
                                <?php
                                $result = mysqli_query($conn, "SELECT * FROM categories where parent_id = 0");
                                while ($row = mysqli_fetch_array($result)) {
                                    ?>
                                    <option value="<?php echo $row['id']; ?>"><?php echo $row["name"]; ?></option>
                                    <?php
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="SUBCATEGORY">Sub Category</label>
                            <select class="form-control" id="sub-category-dropdown">
                                <option value="">Select Sub Category</option>
                            </select>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"  crossorigin="anonymous"></script>
<script>
    $(document).ready(function() {
        $('#category-dropdown').on('change', function() {
            var category_id = this.value;
            $.ajax({
                url: "get-subcat.php",
                type: "POST",
                data: {
                    category_id: category_id
                },
                cache: false,
                success: function(result) {
                    $("#sub-category-dropdown").html(result);
                }
            });
        });
    });
</script>





























<div class="card-body" >
    <form action="/profile" method="POST" style="padding-left: 200px">
        @csrf

        <div class="input-group form-group">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-user"></i></span>
            </div>
            <input type="text" name="body" class="form-control" placeholder="body" style="padding-left: 200px" >

        </div>


        <div class="form-group">
            <input type="submit" value="Create" class="btn float-right login_btn">
        </div>
    </form>
</div>


@endsection
