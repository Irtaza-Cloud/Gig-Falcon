export default class Gate
{
    constructor(user)
    {
        this.user = user;
    }

    isAdmin()
    {
        return this.user.type === 'admin';
    }

    canViewUser()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.view_user;
    }

    canCreateUser()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.create_user;
    }

    canUpdateUser()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.update_user;
    }

    canDeleteUser()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.delete_user;
    }

    canViewHut()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.view_hut;
    }

    canCreateHut()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.create_hut;
    }

    canUpdateHut()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.update_hut;
    }

    canDeleteHut()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.delete_hut;
    }

    canViewFarmHouse()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.view_farmhouse;
    }

    canCreateFarmHouse()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.create_farmhouse;
    }

    canUpdateFarmHouse()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.update_farmhouse;
    }

    canDeleteFarmHouse()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.delete_farmhouse;
    }

    canViewCatering()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.view_catering;
    }

    canCreateCatering()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.create_catering;
    }

    canUpdateCatering()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.update_catering;
    }

    canDeleteCatering()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.delete_catering;
    }

    canViewDecorator()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.view_decorator;
    }

    canCreateDecorator()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.create_decorator;
    }

    canUpdateDecorator()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.update_decorator;
    }

    canDeleteDecorator()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.delete_decorator;
    }
    
    canViewHotelRestaurant()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.view_hotelrestaurant;
    }

    canCreateHotelRestaurant()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.create_hotelrestaurant;
    }

    canUpdateHotelRestaurant()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.update_hotelrestaurant;
    }

    canDeleteHotelRestaurant()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.delete_hotelrestaurant;
    }

    canViewLawnBanquet()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.view_lawnbanquet;
    }

    canCreateLawnBanquet()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.create_lawnbanquet;
    }

    canUpdateLawnBanquet()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.update_lawnbanquet;
    }

    canDeleteLawnBanquet()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.delete_lawnbanquet;
    }

    canViewPhotographer()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.view_photographer;
    }

    canCreatePhotographer()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.create_photographer;
    }

    canUpdatePhotographer()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.update_photographer;
    }

    canDeletePhotographer()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.delete_photographer;
    }

    canViewTransport()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.view_transport;
    }

    canCreateTransport()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.create_transport;
    }

    canUpdateTransport()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.update_transport;
    }

    canDeleteTransport()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.delete_transport;
    }

    canViewTransaction()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.view_transaction;
    }

    canViewBooking()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.view_booking;
    }

    canCreateBooking()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.create_booking;
    }

    canUpdateBooking()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.update_booking;
    }

    canDeleteBooking()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.delete_booking;
    }

    canViewRating()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.view_rating;
    }

    canCreateRating()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.create_rating;
    }

    canUpdateRating()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.update_rating;
    }

    canDeleteRating()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.delete_rating;
    }

    canViewCheckInOut()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.view_checkinout;
    }

    canCreateCheckInOut()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.create_checkinout;
    }

    canUpdateCheckInOut()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.update_checkinout;
    }

    canDeleteCheckInOut()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.delete_checkinout;
    }

    canViewRole()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.view_role;
    }

    canCreateRole()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.create_role;
    }

    canUpdateRole()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.update_role;
    }

    canDeleteRole()
    {
        var permissions = JSON.parse(this.user.roles[0].permissions);
        return permissions.delete_role;
    }
}