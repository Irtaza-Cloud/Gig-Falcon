<template>
    <div class="container" v-if="$gate.canViewUser()">
        <div class="row">
          <div class="col-md-12 mt-3">
            <div class="card">
              <div class="card-header">
                <h2>User Details</h2>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-md-5 col-12">
                    <div class="form-group">
                      <input v-model="dateForm.startDate" class="form-control" id="startDate" type="date" name="startDate" @change="dateFilter(1)">
                    </div>
                  </div>
                  <div class="col-md-5 col-12">
                    <div class="form-group">
                      <input v-model="dateForm.endDate" class="form-control" id="endDate" type="date" name="endDate" @change="dateFilter(1)">
                    </div>
                  </div>
                  <div class="col-md-2 col-12">
                    <div class="form-group">
                      <button class="btn btn-success xs form-control" @click="dateFilter(1)">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title mt-2"></h3>
                  <button v-if="$gate.canCreateUser()" class="btn btn-success xs" id="add_user" @click="AddUserModal">
                      <i class="fas fa-user-plus fa-lg"></i>
                  </button>
                <div class="card-tools mt-2">
                  <div class="input-group input-group-sm" style="width: 350px;">
                    <input v-model="search" type="text" name="table_search" class="form-control float-right" id="table_search" placeholder="Search" @keyup.enter="searchit">
                    <div class="input-group-append ml-2">
                      <button class="btn btn-primary" id="s_btn" @click="searchit">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>

                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Role</th>
                      <th>Image</th>
                      <th>Created At</th>
                      <th>Updated</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-show="loading" class="text-center">
                      <td colspan="8">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="margin: auto; background: none; display: block; shape-rendering: auto; animation-play-state: running; animation-delay: 0s;" width="100px" height="100px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
                          <path d="M10 50A40 40 0 0 0 90 50A40 41.4 0 0 1 10 50" fill="#215d38" stroke="none" style="animation-play-state: running; animation-delay: 0s;">
                            <animateTransform attributeName="transform" type="rotate" dur="0.8928571428571428s" repeatCount="indefinite" keyTimes="0;1" values="0 50 50.7;360 50 50.7" style="animation-play-state: running; animation-delay: 0s;"></animateTransform>
                          </path>
                        </svg>
                      </td>
                    </tr>
                    <tr v-show="!loading" v-for="user in users.data">
                      <td>{{user.id}}</td>
                      <td>{{user.name}}</td>
                      <td>{{user.email}}</td>
                      <td>{{user.roles[0].name | upText}}</td>
                      <td style="width:10%;" @click="OpenImage(user.image)"><img :src="ImageRender(user.image)" style="width:50%;"></td>
                      <td>{{user.created_at | myDate}}</td>
                      <td>{{user.updated_at | humanDate}}</td>
                      <td>
                          <a v-if="$gate.canUpdateUser()" href="javascript:void(0)" @click="EditUserModal(user)">
                            <i class="fas fa-edit blue ml-1"></i>
                          </a>
                          <a v-if="$gate.canDeleteUser()" href="javascript:void(0)" @click="deleteUser(user.id)"><i class="fas fa-trash red ml-1"></i></a>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                <pagination :data="users" @pagination-change-page="getResults"></pagination>
              </div>
            </div>
            <!-- /.card -->
          </div>
        </div>
        <div class="modal fade" id="userModal" tabindex="-1" role="dialog" aria-labelledby="userModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 v-show="!editmode" class="modal-title" id="userModalLabel">Add New User</h5>
                <h5 v-show="editmode" class="modal-title" id="userModalLabel">Update User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <form @submit.prevent="editmode ? updateUser() : createUser()">
              <div class="modal-body">
                <div class="form-group">
                  <label>Name</label>
                  <input v-model="form.name" id="name" type="text" name="name" placeholder="Name"
                    class="form-control" :class="{ 'is-invalid': form.errors.has('name') }">
                  <has-error :form="form" field="name"></has-error>
                </div>
                <div class="form-group">
                  <label>Email</label>
                  <input v-model="form.email" id="email" type="email" name="email" placeholder="Email" 
                    class="form-control" :class="{ 'is-invalid': form.errors.has('email') }">
                  <has-error :form="form" field="email"></has-error>
                </div>
                <div class="form-group">
                  <label>Password</label>
                  <input v-model="form.password" type="password" name="password" placeholder="Password" 
                    class="form-control" :class="{ 'is-invalid': form.errors.has('password') }">
                  <has-error :form="form" field="password"></has-error>
                </div>
                <div class="form-group">
                  <label>Image</label>
                  <input id="image" type="file" name="image"
                    :class="{ 'is-invalid': form.errors.has('image') }">
                  <has-error :form="form" field="image"></has-error>
                </div>
                <div class="form-group">
                  <label>Role</label>
                  <select v-model="form.role" id="role" name="role" class="form-control" :class="{ 'is-invalid': form.errors.has('role') }">
                    <option value="">Select Role</option>
                    <option v-for="role in roles" :value="role.id">{{role.name}}</option>
                  </select>
                  <has-error :form="form" field="role"></has-error>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button v-show="!editmode" type="submit" class="btn btn-primary">Create</button>
                <button v-show="editmode" type="submit" class="btn btn-primary">Update</button>
              </div>
              </form>
            </div>
          </div>
        </div>

        <div class="modal fade" id="imageModal" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="imageModalLabel">Image</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="form-group">
                  <img class="w-100" :src="open_image" alt="">
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
          return{
            loading: true,
            search: '',
            pond:'',
            editmode: false,
            users:{},
            roles:{},
            open_image:'',
            form: new Form({
              id:       '',
              name:     '',
              email:    '',
              password: '',
              image:    '',
              image_name:'',
              role:'',
            }),
            
            dateForm: new Form({
              startDate: '',
              endDate: ''
            })
          }
        },
        methods:{
          OpenImage(image){
            $('#imageModal').modal('show');
            this.open_image = window.domain_url+'/'+image;
          },
          getResults(page = 1) {
            this.loading = true;
            let query = this.search;
            if(query == '' && this.dateForm.startDate == "" && this.dateForm.endDate == ""){
              axios.get('api/user?paginate=1&q='+query+'&page=' + page)
                .then(response => {
                  this.users = response.data;
                  this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
            else if(this.dateForm.startDate != "" || this.dateForm.endDate != ""){
              this.dateFilter(page);
            }
            else{
              axios.get('api/finduser?q='+query+'&page=' + page).then(({data})=>{
                this.users = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
          },
          dateFilter(page){
            this.loading = true;
            this.dateForm.post('api/date_search_user?page='+page)
              .then(response => {
                this.users = response.data;
                this.loading = false;
            }).catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
            });
          },
          ImageRender(image){
            return window.domain_url+'/'+image;
          },
          InitializeFilePond(){
            const inputElement = document.querySelector('input[type="file"]');
            this.pond = FilePond.create(inputElement,{
              credits: false,
            });
          },
          SetFilePond(){
            var fileId = Date.now();
            FilePond.setOptions({
              server: {
                process: {
                  url: 'api/file_upload?fileId='+fileId,
                  method: 'POST',
                  headers: {
                    'X-XSRF-TOKEN':document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                  },
                  onload: (response) => {
                    this.form.image = response;
                  },
                },
                revert: {
                  url: 'api/file_delete?fileId='+fileId,
                  method: 'POST',
                  headers: {
                    'X-XSRF-TOKEN':document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                  },
                  onload: (response) => {
                    this.form.image = '';
                  },
                }
              }
            });
          },
          AddUserModal(){
            this.SetFilePond();
            this.form.reset();
            this.editmode = false;
            this.form.image = '';
            this.pond.removeFiles();
            $('#userModal').modal('show');
          },
          EditUserModal(user){
            this.SetFilePond();
            this.form.fill(user);
            this.editmode = true;
            this.form.role = user.roles[0].id;
            this.form.image = '';
            this.pond.removeFiles();
            $('#userModal').modal('show');
          },
          deleteUser(id){
            Swal.fire({
              title: 'Are you sure?',
              text: "You won't be able to revert this!",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                  this.form.delete('api/user/'+id).then(()=>(this.searchit()));
                  Swal.fire(
                    'Deleted!',
                    'Your file has been deleted.',
                    'success'
                  );
                }
            }).catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
              else if(error.response.status != 401){
                Toast.fire({
                  icon: 'error',
                  title: 'Something went wrong'
                });
                this.$Progress.finish();
              }
            });
          },
          loadUser(){
              axios.get('api/user?paginate=1').then(({data})=>{
                this.users = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
          },
          loadRole(){
              axios.get('api/role').then(({data})=>{
                this.roles = data;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
          },
          createUser(){
            this.$Progress.start();
            this.form.post('api/user')
            .then(()=>{
              this.loadUser();
              $('#userModal').modal('hide');
              Toast.fire({
                icon: 'success',
                title: 'User Created Successfully'
              });
              this.$Progress.finish();
            })
            .catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
              else if(error.response.status != 401){
                Toast.fire({
                  icon: 'error',
                  title: 'Something went wrong'
                });
                this.$Progress.finish();
              }
            });
          },
          updateUser(){
            this.$Progress.start();
            this.form.put('api/user/'+this.form.id)
            .then(()=>{
              $('#userModal').modal('hide');
              Toast.fire({
                icon: 'success',
                title: 'User Updated Successfully'
              });
              this.$Progress.finish();
            }).then(()=>(this.searchit())).
            catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
              else if(error.response.status != 401){
                Toast.fire({
                  icon: 'error',
                  title: 'Something went wrong'
                });
                this.$Progress.finish();
              }
            });
          },
          searchit(){
            this.loading = true;
            let query = this.search;
            this.dateForm.startDate = '';
            this.dateForm.endDate = '';
            if(query == ''){
              this.loadUser();
            }
            else{
              axios.get('api/finduser?q='+query).then(({data})=>{
                this.users = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
          },
        },
        mounted() {
            this.loadUser();
            this.loadRole();
            this.InitializeFilePond();
            if(!this.$gate.canViewUser()){
              this.$router.push('NotFound');
            }
        }
    };
</script>
