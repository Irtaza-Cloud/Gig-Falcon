<template>
    <div class="container" v-if="$gate.canViewTransaction()">
        <div class="row">
          <div class="col-md-12 mt-3">
            <div class="card">
              <div class="card-header">
                <h2>Transaction Details</h2>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-md-5 col-12">
                    <div class="form-group">
                      <input v-model="dateForm.startDate" class="form-control" id="startDate" type="date" name="startDate" @change="dateFilter(1)">
                    </div>
                  </div>
                  <div class="col-md-5 col-12">
                    <div class="form-group">
                      <input v-model="dateForm.endDate" class="form-control" id="endDate" type="date" name="endDate" @change="dateFilter(1)">
                    </div>
                  </div>
                  <div class="col-md-2 col-12">
                    <div class="form-group">
                      <button class="btn btn-success xs form-control" @click="dateFilter(1)">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title mt-2"></h3>
                <div class="card-tools mt-2">
                  <div class="input-group input-group-sm" style="width: 350px;">
                    <input v-model="search" type="text" name="table_search" class="form-control float-right" id="table_search" placeholder="Search" @keyup.enter="searchit">
                    <div class="input-group-append ml-2">
                      <button class="btn btn-primary" id="s_btn" @click="searchit">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>

                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0 text-center">
                <table class="table table-hover text-nowrap">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>User</th>
                      <th>Vendor</th>
                      <th>Name</th>
                      <th>Amount</th>
                      <th>Created</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-show="loading">
                      <td colspan="8">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="margin: auto; background: none; display: block; shape-rendering: auto; animation-play-state: running; animation-delay: 0s;" width="100px" height="100px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
                          <path d="M10 50A40 40 0 0 0 90 50A40 41.4 0 0 1 10 50" fill="#215d38" stroke="none" style="animation-play-state: running; animation-delay: 0s;">
                            <animateTransform attributeName="transform" type="rotate" dur="0.8928571428571428s" repeatCount="indefinite" keyTimes="0;1" values="0 50 50.7;360 50 50.7" style="animation-play-state: running; animation-delay: 0s;"></animateTransform>
                          </path>
                        </svg>
                      </td>
                    </tr>
                    <tr v-show="!loading" v-for="(transaction,index) in transactions.data" v-bind:key="index">
                      <td>{{transaction.id}}</td>
                      <td>{{transaction.user.name}}</td>
                      <td>{{transaction.vendor.name}}</td>
                      <td v-if="transaction.huts">
                        <b>Hut: </b>{{transaction.huts.name}}
                      </td>
                      <td v-else-if="transaction.caterings">
                        <b>Catering: </b>{{transaction.caterings.name}}
                      </td>
                      <td v-else-if="transaction.decorators">
                        <b>Decorator: </b>{{transaction.decorators.name}}
                      </td>
                      <td v-else-if="transaction.photographers">
                        <b>Photographer: </b>{{transaction.photographers.name}}
                      </td>
                      <td v-else-if="transaction.farmhouses">
                        <b>Farm House: </b>{{transaction.farmhouses.name}}
                      </td>
                      <td v-else-if="transaction.hotelrestaurants">
                        <b>Hotel Restaurant: </b>{{transaction.hotelrestaurants.name}}
                      </td>
                      <td v-else-if="transaction.lawnbanquets">
                        <b>Lawn Banquet: </b>{{transaction.lawnbanquets.name}}
                      </td>
                      <td v-else-if="transaction.transports">
                        <b>Transport: </b>{{transaction.transports.name}}
                      </td>
                      <td>{{transaction.amount}}</td>
                      <td>{{transaction.created_at | myDate}}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                <pagination :data="transactions" @pagination-change-page="getResults"></pagination>
              </div>
            </div>
            <!-- /.card -->
          </div>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
          return{
            loading: true,
            search: '',
            editmode: false,
            transactions:{},
            
            dateForm: new Form({
              startDate: '',
              endDate: ''
            })
          }
        },
        methods:{
          getResults(page = 1) {
            this.loading = true;
            let query = this.search;
            if(query == '' && this.dateForm.startDate == "" && this.dateForm.endDate == ""){
              axios.get('api/transaction?paginate=1&q='+query+'&page=' + page)
                .then(response => {
                  this.transactions = response.data;
                  this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
            else if(this.dateForm.startDate != "" || this.dateForm.endDate != ""){
              this.dateFilter(page);
            }
            else{
              axios.get('api/findtransaction?q='+query+'&page=' + page).then(({data})=>{
                this.transactions = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
          },
          dateFilter(page){
            this.loading = true;
            this.dateForm.post('api/date_search_transaction?page='+page)
              .then(response => {
                this.transactions = response.data;
                this.loading = false;
            }).catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
            });
          },
          loadTransaction(){
              axios.get('api/transaction?paginate=1').then(({data})=>{
                this.transactions = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
          },
          searchit(){
            this.loading = true;
            let query = this.search;
            this.dateForm.startDate = '';
            this.dateForm.endDate = '';
            if(query == ''){
              this.loadTransaction();
            }
            else{
              axios.get('api/findtransaction?q='+query).then(({data})=>{
                this.transactions = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
          },
        },
        mounted() {
            this.loadTransaction();
            if(!this.$gate.canViewTransaction()){
              this.$router.push('NotFound');
            }
        }
    };
</script>
