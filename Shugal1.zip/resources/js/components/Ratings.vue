<template>
    <div class="container" v-if="$gate.canViewRating()">
        <div class="row">
          <div class="col-md-12 mt-3">
            <div class="card">
              <div class="card-header">
                <h2>Rating Details</h2>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-md-5 col-12">
                    <div class="form-group">
                      <input v-model="dateForm.startDate" class="form-control" id="startDate" type="date" name="startDate" @change="dateFilter(1)">
                    </div>
                  </div>
                  <div class="col-md-5 col-12">
                    <div class="form-group">
                      <input v-model="dateForm.endDate" class="form-control" id="endDate" type="date" name="endDate" @change="dateFilter(1)">
                    </div>
                  </div>
                  <div class="col-md-2 col-12">
                    <div class="form-group">
                      <button class="btn btn-success xs form-control" @click="dateFilter(1)">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title mt-2"></h3>
                  <!-- <button v-if="$gate.canCreateRating()" class="btn btn-success xs" id="add_rating" @click="AddRatingModal">
                      <i class="fas fa-plus fa-lg"></i>
                  </button> -->
                <div class="card-tools mt-2">
                  <div class="input-group input-group-sm" style="width: 350px;">
                    <input v-model="search" type="text" name="table_search" class="form-control float-right" id="table_search" placeholder="Search" @keyup.enter="searchit">
                    <div class="input-group-append ml-2">
                      <button class="btn btn-primary" id="s_btn" @click="searchit">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>

                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Hut</th>
                      <th>Rating</th>
                      <th>Created At</th>
                      <!-- <th>Updated</th>
                      <th>Actions</th> -->
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-show="loading" class="text-center">
                      <td colspan="8">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="margin: auto; background: none; display: block; shape-rendering: auto; animation-play-state: running; animation-delay: 0s;" width="100px" height="100px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
                          <path d="M10 50A40 40 0 0 0 90 50A40 41.4 0 0 1 10 50" fill="#215d38" stroke="none" style="animation-play-state: running; animation-delay: 0s;">
                            <animateTransform attributeName="transform" type="rotate" dur="0.8928571428571428s" repeatCount="indefinite" keyTimes="0;1" values="0 50 50.7;360 50 50.7" style="animation-play-state: running; animation-delay: 0s;"></animateTransform>
                          </path>
                        </svg>
                      </td>
                    </tr>
                    <tr v-show="!loading" v-for="(rating,index) in ratings.data" v-bind:key="index">
                      <td>{{rating.id}}</td>
                      <td>{{rating.user.name}}</td>
                      <td>{{rating.hut.name}}</td>
                      <td>{{rating.rating}}</td>
                      <td>{{rating.created_at | myDate}}</td>
                      <!-- <td>{{rating.updated_at | humanDate}}</td> -->
                      <!-- <td>
                          <a v-if="$gate.canUpdateRating()" href="javascript:void(0)" @click="EditRatingModal(rating)">
                            <i class="fas fa-edit blue ml-1"></i>
                          </a>
                          <a v-if="$gate.canDeleteRating()" href="javascript:void(0)" @click="deleteRating(rating.id)"><i class="fas fa-trash red ml-1"></i></a>
                      </td> -->
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                <pagination :data="ratings" @pagination-change-page="getResults"></pagination>
              </div>
            </div>
            <!-- /.card -->
          </div>
        </div>
        <div class="modal fade" id="ratingModal" tabindex="-1" role="dialog" aria-labelledby="ratingModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 v-show="!editmode" class="modal-title" id="ratingModalLabel">Add New Rating</h5>
                <h5 v-show="editmode" class="modal-title" id="ratingModalLabel">Update Rating</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <form @submit.prevent="editmode ? updateRating() : createRating()">
              <div class="modal-body">
                <div class="form-group">
                  <label>Hut</label>
                  <select v-model="form.hut_id" id="hut_id" type="text" name="hut_id" placeholder="Name" class="form-control" :class="{ 'is-invalid': form.errors.has('hut_id') }">
                        <option value="">Select Hut</option>
                        <option v-for="(hut,index) in huts" v-bind:key="index" :value="hut.id">
                            {{hut.name}}
                        </option>
                  </select>
                  <has-error :form="form" field="hut_id"></has-error>
                </div>
                <div class="form-group">
                  <label>Room</label>
                  <input v-model="form.room" id="room" type="room" name="room" placeholder="Select Room" 
                    class="form-control" :class="{ 'is-invalid': form.errors.has('room') }">
                  <has-error :form="form" field="room"></has-error>
                </div>
                <div class="form-group">
                  <label>Rating Date</label>
                  <input v-model="form.rating_date" type="date" name="rating_date" placeholder="Select Date" 
                    class="form-control" :class="{ 'is-invalid': form.errors.has('rating_date') }">
                  <has-error :form="form" field="rating_date"></has-error>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button v-show="!editmode" type="submit" class="btn btn-primary">Create</button>
                <button v-show="editmode" type="submit" class="btn btn-primary">Update</button>
              </div>
              </form>
            </div>
          </div>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
          return{
            loading: true,
            search: '',
            pond:'',
            editmode: false,
            ratings:{},
            huts:{},
            form: new Form({
              id:       '',
              hut_id:     '',
              room: '',
              rating_date:    '',
            }),
            
            dateForm: new Form({
              startDate: '',
              endDate: ''
            })
          }
        },
        methods:{
          getResults(page = 1) {
            this.loading = true;
            let query = this.search;
            if(query == '' && this.dateForm.startDate == "" && this.dateForm.endDate == ""){
              axios.get('api/rating?paginate=1&q='+query+'&page=' + page)
                .then(response => {
                  this.ratings = response.data;
                  this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
            else if(this.dateForm.startDate != "" || this.dateForm.endDate != ""){
              this.dateFilter(page);
            }
            else{
              axios.get('api/findrating?q='+query+'&page=' + page).then(({data})=>{
                this.ratings = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
          },
          dateFilter(page){
            this.loading = true;
            this.dateForm.post('api/date_search_rating?page='+page)
              .then(response => {
                this.ratings = response.data;
                this.loading = false;
            }).catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
            });
          },
          ImageRender(image){
            return process.env.MIX_DOMAIN+image;
          },
          InitializeFilePond(){
            const inputElement = document.querySelector('input[type="file"]');
            this.pond = FilePond.create(inputElement,{
              credits: false,
            });
          },
          SetFilePond(){
            var fileId = Date.now();
            FilePond.setOptions({
              server: {
                process: {
                  url: 'api/file_upload?fileId='+fileId,
                  method: 'POST',
                  headers: {
                    'X-XSRF-TOKEN':document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                  },
                  onload: (response) => {
                    this.form.image = response;
                  },
                },
                revert: {
                  url: 'api/file_delete?fileId='+fileId,
                  method: 'POST',
                  headers: {
                    'X-XSRF-TOKEN':document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                  },
                  onload: (response) => {
                    this.form.image = '';
                  },
                }
              }
            });
          },
          AddRatingModal(){
            this.SetFilePond();
            this.form.reset();
            this.editmode = false;
            this.form.image = '';
            this.pond.removeFiles();
            $('#ratingModal').modal('show');
          },
          EditRatingModal(rating){
            this.SetFilePond();
            this.form.fill(rating);
            this.editmode = true;
            this.form.image = '';
            this.pond.removeFiles();
            $('#ratingModal').modal('show');
          },
          deleteRating(id){
            Swal.fire({
              title: 'Are you sure?',
              text: "You won't be able to revert this!",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                  this.form.delete('api/rating/'+id).then(()=>(this.searchit()));
                  Swal.fire(
                    'Deleted!',
                    'Your file has been deleted.',
                    'success'
                  );
                }
            }).catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
              else if(error.response.status != 401){
                Toast.fire({
                  icon: 'error',
                  title: 'Something went wrong'
                });
                this.$Progress.finish();
              }
            });
          },
          loadRating(){
              axios.get('api/rating?paginate=1').then(({data})=>{
                this.ratings = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
          },
          loadHuts(){
            axios.get('api/hut').then(({data})=>{
                this.huts = data;
            }).catch((error)=>{
                if(error.response.status == 401){
                    location.reload();
                }
            });
          },
          createRating(){
            this.$Progress.start();
            this.form.post('api/rating')
            .then(()=>{
              this.loadRating();
              $('#ratingModal').modal('hide');
              Toast.fire({
                icon: 'success',
                title: 'Rating Created Successfully'
              });
              this.$Progress.finish();
            })
            .catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
              else if(error.response.status != 401){
                Toast.fire({
                  icon: 'error',
                  title: 'Something went wrong'
                });
                this.$Progress.finish();
              }
            });
          },
          updateRating(){
            this.$Progress.start();
            this.form.put('api/rating/'+this.form.id)
            .then(()=>{
              $('#ratingModal').modal('hide');
              Toast.fire({
                icon: 'success',
                title: 'Rating Updated Successfully'
              });
              this.$Progress.finish();
            }).then(()=>(this.searchit())).
            catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
              else if(error.response.status != 401){
                Toast.fire({
                  icon: 'error',
                  title: 'Something went wrong'
                });
                this.$Progress.finish();
              }
            });
          },
          searchit(){
            this.loading = true;
            let query = this.search;
            this.dateForm.startDate = '';
            this.dateForm.endDate = '';
            if(query == ''){
              this.loadRating();
            }
            else{
              axios.get('api/findrating?q='+query).then(({data})=>{
                this.ratings = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
          },
        },
        mounted() {
            this.loadRating();
            // this.loadHuts();
            // this.InitializeFilePond();
            // if(!this.$gate.canViewRating()){
            //   this.$router.push('NotFound');
            // }
        }
    };
</script>
