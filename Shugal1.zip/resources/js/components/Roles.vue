<template>
    <div class="container" v-if="$gate.canViewRole()">
        <div class="row">
          <div class="col-md-12 mt-3">
            <div class="card">
              <div class="card-header">
                <h2>Role Details</h2>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-md-5">
                    <div class="form-group">
                      <input v-model="dateForm.startDate" class="form-control" id="startDate" type="date" name="startDate" @change="dateFilter(1)">
                    </div>
                  </div>
                  <div class="col-md-5">
                      <input v-model="dateForm.endDate" class="form-control" id="endDate" type="date" name="endDate" @change="dateFilter(1)">
                  </div>
                  <div class="col-md-2">
                    <button class="btn btn-success xs" @click="dateFilter(1)">
                      <i class="fas fa-search"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title mt-2"></h3>
                  <button class="btn btn-success xs" id="add_role" @click="AddRoleModal">
                      <i class="fas fa-plus fa-lg"></i>
                  </button>
                <div class="card-tools mt-2">
                  <div class="input-group input-group-sm" style="width: 350px;">
                    <input v-model="search" type="text" name="table_search" class="form-control float-right" id="table_search" placeholder="Search" @keyup.enter="searchit">
                    <div class="input-group-append ml-2">
                      <button class="btn btn-primary" id="s_btn" @click="searchit">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>

                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Permissions</th>
                      <th>Created At</th>
                      <th>Updated</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-show="loading" class="text-center">
                      <td colspan="6">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="margin: auto; background: none; display: block; shape-rendering: auto; animation-play-state: running; animation-delay: 0s;" width="100px" height="100px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
                          <path d="M10 50A40 40 0 0 0 90 50A40 41.4 0 0 1 10 50" fill="#215d38" stroke="none" style="animation-play-state: running; animation-delay: 0s;">
                            <animateTransform attributeName="transform" type="rotate" dur="0.8928571428571428s" repeatCount="indefinite" keyTimes="0;1" values="0 50 50.7;360 50 50.7" style="animation-play-state: running; animation-delay: 0s;"></animateTransform>
                          </path>
                        </svg>
                      </td>
                    </tr>
                    <tr v-show="!loading" v-for="role in roles.data">
                      <td>{{role.id}}</td>
                      <td>{{role.name}}</td>
                      <td>
                        <span v-for="(key,index) in Object.keys(JSON.parse(role.permissions))">
                          <button class="btn btn-success btn-xs" style="font-size: 11px;padding: revert;margin-right:1px;">
                            {{key}}
                          </button>
                          <p v-if="((index+1)%4) == 0"></p>
                        </span>
                      </td>
                      <td>{{role.created_at | myDate}}</td>
                      <td>{{role.updated_at | humanDate}}</td>
                      <td>
                          <a v-if="$gate.canUpdateRole()" href="javascript:void(0)" @click="EditRoleModal(role)">
                            <i class="fas fa-edit blue ml-1"></i>
                          </a>
                          <a v-if="$gate.canUpdateRole()" href="javascript:void(0)" @click="deleteRole(role.id)"><i class="fas fa-trash red ml-1"></i></a>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                <pagination :data="roles" @pagination-change-page="getResults"></pagination>
              </div>
            </div>
            <!-- /.card -->
          </div>
        </div>
        <div class="modal fade" id="roleModal" tabindex="-1" role="dialog" aria-labelledby="roleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 v-show="!editmode" class="modal-title" id="roleModalLabel">Add New Role</h5>
                <h5 v-show="editmode" class="modal-title" id="roleModalLabel">Update Role</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <form @submit.prevent="editmode ? updateRole() : createRole()">
              <div class="modal-body">
                <div class="form-group">
                  <label>Name</label>
                  <input v-model="form.name" id="name" type="text" name="name" placeholder="Name"
                    class="form-control" :class="{ 'is-invalid': form.errors.has('name') }">
                  <has-error :form="form" field="name"></has-error>
                </div>
                <div class="form-group">
                  <label>Type</label>
                  <multiselect 
                    v-model="form.permissions" 
                    :options="options" 
                    :multiple="true" 
                    group-values="options"
                    group-label="select_all"
                    :group-select="true"
                    placeholder="Type to search" 
                    track-by="name" 
                    label="name" 
                    :class="{ 'is-invalid': form.errors.has('permissions') }">
                      <span slot="noResult">Oops! No elements found. Consider changing the search query.</span>
                  </multiselect>
                  <has-error :form="form" field="permissions"></has-error>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button v-show="!editmode" type="submit" class="btn btn-primary">Create</button>
                <button v-show="editmode" type="submit" class="btn btn-primary">Update</button>
              </div>
              </form>
            </div>
          </div>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
          return{
            loading:true,
            search: '',
            vselect:'',
            editmode: false,
            roles:{},
            options: [
              {
                select_all:'Select all',
                options:[
                  { name: 'view_user', value: 'true' },
                  { name: 'create_user', value: 'true' },
                  { name: 'update_user', value: 'true' },
                  { name: 'delete_user', value: 'true' },
                  { name: 'view_hut', value: 'true' },
                  { name: 'create_hut', value: 'true' },
                  { name: 'update_hut', value: 'true' },
                  { name: 'delete_hut', value: 'true' },
                  { name: 'view_farmhouse', value: 'true' },
                  { name: 'create_farmhouse', value: 'true' },
                  { name: 'update_farmhouse', value: 'true' },
                  { name: 'delete_farmhouse', value: 'true' },
                  { name: 'view_catering', value: 'true' },
                  { name: 'create_catering', value: 'true' },
                  { name: 'update_catering', value: 'true' },
                  { name: 'delete_catering', value: 'true' },
                  { name: 'view_decorator', value: 'true' },
                  { name: 'create_decorator', value: 'true' },
                  { name: 'update_decorator', value: 'true' },
                  { name: 'delete_decorator', value: 'true' },
                  { name: 'view_photographer', value: 'true' },
                  { name: 'create_photographer', value: 'true' },
                  { name: 'update_photographer', value: 'true' },
                  { name: 'delete_photographer', value: 'true' },
                  { name: 'view_hotelrestaurant', value: 'true' },
                  { name: 'create_hotelrestaurant', value: 'true' },
                  { name: 'update_hotelrestaurant', value: 'true' },
                  { name: 'delete_hotelrestaurant', value: 'true' },
                  { name: 'view_lawnbanquet', value: 'true' },
                  { name: 'create_lawnbanquet', value: 'true' },
                  { name: 'update_lawnbanquet', value: 'true' },
                  { name: 'delete_lawnbanquet', value: 'true' },
                  { name: 'view_transport', value: 'true' },
                  { name: 'create_transport', value: 'true' },
                  { name: 'update_transport', value: 'true' },
                  { name: 'delete_transport', value: 'true' },
                  { name: 'view_booking', value: 'true' },
                  { name: 'create_booking', value: 'true' },
                  { name: 'update_booking', value: 'true' },
                  { name: 'delete_booking', value: 'true' },
                  { name: 'view_rating', value: 'true' },
                  { name: 'create_rating', value: 'true' },
                  { name: 'view_transaction', value: 'true' },
                  // { name: 'update_rating', value: 'true' },
                  // { name: 'delete_rating', value: 'true' },
                  // { name: 'view_checkinout', value: 'true' },
                  // { name: 'create_checkinout', value: 'true' },
                  // { name: 'update_checkinout', value: 'true' },
                  // { name: 'delete_checkinout', value: 'true' },
                  { name: 'view_role', value: 'true' },
                  { name: 'create_role', value: 'true' },
                  { name: 'update_role', value: 'true' },
                  { name: 'delete_role', value: 'true' },
                ]
              }
            ],
            form: new Form({
              id:       '',
              name:     '',
              permissions:[],
            }),
            dateForm: new Form({
              startDate: '',
              endDate: ''
            })
          }
        },
        methods:{
          getResults(page = 1) {
            this.loading = true;
            let query = this.search;
            if(query == '' && this.dateForm.startDate == "" && this.dateForm.endDate == ""){
              axios.get('api/role?paginate=1&q='+query+'&page=' + page)
                .then(response => {
                  this.roles = response.data;
                  this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
            else if(this.dateForm.startDate != "" || this.dateForm.endDate != ""){
              this.dateFilter(page);
            }
            else{
              axios.get('api/findrole?q='+query+'&page=' + page).then(({data})=>{
                this.roles = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
          },
          dateFilter(page){
            this.loading = true;
            this.dateForm.post('api/date_search_role?page='+page)
              .then(response => {
                this.roles = response.data;
                this.loading = false;
            }).catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
            });
          },
          ImageRender(image){
            return process.env.MIX_DOMAIN+image;
          },
          AddRoleModal(){
            this.form.reset();
            this.editmode = false;
            $('input[type="file"]').val(null);
            $('#roleModal').modal('show');
          },
          EditRoleModal(role){
            this.form.fill(role);
            this.form.permissions = [];
            var keys = Object.keys(JSON.parse(role.permissions));
            for(var i=0; i<keys.length; i++){
              this.form.permissions.push({
                name:keys[i],
                value:'true'
              });
            }
            this.editmode = true;
            $('input[type="file"]').val(null);
            $('#roleModal').modal('show');
          },
          deleteRole(id){
            Swal.fire({
              title: 'Are you sure?',
              text: "You won't be able to revert this!",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                  this.form.delete('api/role/'+id).then(()=>(this.searchit()));
                  Swal.fire(
                    'Deleted!',
                    'Your file has been deleted.',
                    'success'
                  );
                }
            }).catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
            });
          },
          loadRole(){
              axios.get('api/role?paginate=1').then(({data})=>{
                this.roles = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
          },
          createRole(){
            this.$Progress.start();
            this.form.post('api/role')
            .then(()=>{
              this.loadRole();
              $('#roleModal').modal('hide');
              Toast.fire({
                icon: 'success',
                title: 'Role Created Successfully'
              });
              this.$Progress.finish();
            })
            .catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
            });
          },
          updateRole(){
            this.$Progress.start();
            this.form.put('api/role/'+this.form.id)
            .then(()=>{
              $('#roleModal').modal('hide');
              Toast.fire({
                icon: 'success',
                title: 'Role Updated Successfully'
              });
              this.$Progress.finish();
            }).then(()=>(this.searchit())).
            catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
            });
          },
          searchit(){
            this.loading = true;
            let query = this.search;
            this.dateForm.startDate = '';
            this.dateForm.endDate = '';
            if(query == ''){
              this.loadRole();
            }
            else{
              axios.get('api/findrole?q='+query).then(({data})=>{
                this.roles = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
          },
        },
        mounted() {
            this.loadRole();
            if(!this.$gate.canViewRole()){
              this.$router.push('NotFound');
            }
        }
    };
</script>
<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>
