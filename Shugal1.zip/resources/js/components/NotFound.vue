<template>
    <div class="container">
      <div class="row text-center">
        <div class="col-md-12 mt-5">
          <h1 style="font-size: 1000%;">404</h1>
          <h1>NOT FOUND</h1>
        </div>
      </div>
    </div>
</template>

<script>
    export default {
        data(){
            return{

            }
        },
        methods:{
        },
        mounted() {
        }
    };
</script>
