<template>
    <div class="container" v-if="$gate.canViewBooking()">
        <div class="row">
          <div class="col-md-12 mt-3">
            <div class="card">
              <div class="card-header">
                <h2>Booking Details</h2>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-md-5 col-12">
                    <div class="form-group">
                      <input v-model="dateForm.startDate" class="form-control" id="startDate" type="date" name="startDate" @change="dateFilter(1)">
                    </div>
                  </div>
                  <div class="col-md-5 col-12">
                    <div class="form-group">
                      <input v-model="dateForm.endDate" class="form-control" id="endDate" type="date" name="endDate" @change="dateFilter(1)">
                    </div>
                  </div>
                  <div class="col-md-2 col-12">
                    <div class="form-group">
                      <button class="btn btn-success xs form-control" @click="dateFilter(1)">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title mt-2"></h3>
                  <button v-if="$gate.canCreateBooking()" class="btn btn-success xs" id="add_booking" @click="AddBookingModal">
                      <i class="fas fa-plus fa-lg"></i>
                  </button>
                <div class="card-tools mt-2">
                  <div class="input-group input-group-sm" style="width: 350px;">
                    <input v-model="search" type="text" name="table_search" class="form-control float-right" id="table_search" placeholder="Search" @keyup.enter="searchit">
                    <div class="input-group-append ml-2">
                      <button class="btn btn-primary" id="s_btn" @click="searchit">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>

                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Booking Date</th>
                      <th>Created At</th>
                      <th>Updated</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-show="loading" class="text-center">
                      <td colspan="8">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="margin: auto; background: none; display: block; shape-rendering: auto; animation-play-state: running; animation-delay: 0s;" width="100px" height="100px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
                          <path d="M10 50A40 40 0 0 0 90 50A40 41.4 0 0 1 10 50" fill="#215d38" stroke="none" style="animation-play-state: running; animation-delay: 0s;">
                            <animateTransform attributeName="transform" type="rotate" dur="0.8928571428571428s" repeatCount="indefinite" keyTimes="0;1" values="0 50 50.7;360 50 50.7" style="animation-play-state: running; animation-delay: 0s;"></animateTransform>
                          </path>
                        </svg>
                      </td>
                    </tr>
                    <tr v-show="!loading" v-for="(booking,index) in bookings.data" v-bind:key="index">
                      <td>{{booking.id}}</td>
                      <td v-if="booking.huts">
                        <b>Hut: </b>{{booking.huts.name}}
                      </td>
                      <td v-else-if="booking.caterings">
                        <b>Catering: </b>{{booking.caterings.name}}
                      </td>
                      <td v-else-if="booking.decorators">
                        <b>Decorator: </b>{{booking.decorators.name}}
                      </td>
                      <td v-else-if="booking.photographers">
                        <b>Photographer: </b>{{booking.photographers.name}}
                      </td>
                      <td v-else-if="booking.farmhouses">
                        <b>Farm House: </b>{{booking.farmhouses.name}}
                      </td>
                      <td v-else-if="booking.hotelrestaurants">
                        <b>Hotel Restaurant: </b>{{booking.hotelrestaurants.name}}
                      </td>
                      <td v-else-if="booking.lawnbanquets">
                        <b>Lawn Banquet: </b>{{booking.lawnbanquets.name}}
                      </td>
                      <td v-else-if="booking.transports">
                        <b>Transport: </b>{{booking.transports.name}}
                      </td>
                      <td>{{booking.booking_date}}</td>
                      <td>{{booking.created_at | myDate}}</td>
                      <td>{{booking.updated_at | humanDate}}</td>
                      <td>
                          <a v-if="$gate.canUpdateBooking()" href="javascript:void(0)" @click="EditBookingModal(booking)">
                            <i class="fas fa-edit blue ml-1"></i>
                          </a>
                          <a v-if="$gate.canDeleteBooking()" href="javascript:void(0)" @click="deleteBooking(booking.id)"><i class="fas fa-trash red ml-1"></i></a>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                <pagination :data="bookings" @pagination-change-page="getResults"></pagination>
              </div>
            </div>
            <!-- /.card -->
          </div>
        </div>
        <div class="modal fade" id="bookingModal" tabindex="-1" role="dialog" aria-labelledby="bookingModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 v-show="!editmode" class="modal-title" id="bookingModalLabel">Add New Booking</h5>
                <h5 v-show="editmode" class="modal-title" id="bookingModalLabel">Update Booking</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <form @submit.prevent="editmode ? updateBooking() : createBooking()">
              <div class="modal-body">
                <div class="form-group">
                  <label>Hut</label>
                  <select v-model="form.hut_id" id="hut_id" type="text" name="hut_id" placeholder="Name" class="form-control" :class="{ 'is-invalid': form.errors.has('hut_id') }" @change="itemSelect('hut_id')">
                        <option value="">Select Hut</option>
                        <option v-for="(hut,index) in huts" v-bind:key="index" :value="hut.id">
                            {{hut.name}}
                        </option>
                  </select>
                  <has-error :form="form" field="hut_id"></has-error>
                </div>
                <div class="form-group">
                  <label>Catering</label>
                  <select v-model="form.catering_id" id="catering_id" type="text" name="catering_id" placeholder="Name" class="form-control" :class="{ 'is-invalid': form.errors.has('catering_id') }" @change="itemSelect('catering_id')">
                        <option value="">Select Catering</option>
                        <option v-for="(catering,index) in caterings" v-bind:key="index" :value="catering.id">
                            {{catering.name}}
                        </option>
                  </select>
                  <has-error :form="form" field="catering_id"></has-error>
                </div>
                <div class="form-group">
                  <label>Decorator</label>
                  <select v-model="form.decorator_id" id="decorator_id" type="text" name="decorator_id" placeholder="Name" class="form-control" :class="{ 'is-invalid': form.errors.has('decorator_id') }" @change="itemSelect('decorator_id')">
                        <option value="">Select Decorator</option>
                        <option v-for="(decorator,index) in decorators" v-bind:key="index" :value="decorator.id">
                            {{decorator.name}}
                        </option>
                  </select>
                  <has-error :form="form" field="decorator_id"></has-error>
                </div>
                <div class="form-group">
                  <label>Photographer</label>
                  <select v-model="form.photographer_id" id="photographer_id" type="text" name="photographer_id" placeholder="Name" class="form-control" :class="{ 'is-invalid': form.errors.has('photographer_id') }" @change="itemSelect('photographer_id')">
                        <option value="">Select Photographer</option>
                        <option v-for="(photographer,index) in photographers" v-bind:key="index" :value="photographer.id">
                            {{photographer.name}}
                        </option>
                  </select>
                  <has-error :form="form" field="photographer_id"></has-error>
                </div>
                <div class="form-group">
                  <label>Farm House</label>
                  <select v-model="form.farm_house_id" id="farm_house_id" type="text" name="farm_house_id" placeholder="Name" class="form-control" :class="{ 'is-invalid': form.errors.has('farm_house_id') }" @change="itemSelect('farm_house_id')">
                        <option value="">Select Farm House</option>
                        <option v-for="(farmhouse,index) in farmhouses" v-bind:key="index" :value="farmhouse.id">
                            {{farmhouse.name}}
                        </option>
                  </select>
                  <has-error :form="form" field="farm_house_id"></has-error>
                </div>
                <div class="form-group">
                  <label>Hotel Restaurant</label>
                  <select v-model="form.hotel_restaurant_id" id="hotel_restaurant_id" type="text" name="hotel_restaurant_id" placeholder="Name" class="form-control" :class="{ 'is-invalid': form.errors.has('hotel_restaurant_id') }" @change="itemSelect('hotel_restaurant_id')">
                        <option value="">Select Hotel Restaurant</option>
                        <option v-for="(hotelrestaurant,index) in hotelrestaurants" v-bind:key="index" :value="hotelrestaurant.id">
                            {{hotelrestaurant.name}}
                        </option>
                  </select>
                  <has-error :form="form" field="hotel_restaurant_id"></has-error>
                </div>
                <div class="form-group">
                  <label>Lawn Banquet</label>
                  <select v-model="form.lawn_banquet_id" id="lawn_banquet_id" type="text" name="lawn_banquet_id" placeholder="Name" class="form-control" :class="{ 'is-invalid': form.errors.has('lawn_banquet_id') }" @change="itemSelect('lawn_banquet_id')">
                        <option value="">Select Lawn Banquet</option>
                        <option v-for="(lawnbanquet,index) in lawnbanquets" v-bind:key="index" :value="lawnbanquet.id">
                            {{lawnbanquet.name}}
                        </option>
                  </select>
                  <has-error :form="form" field="lawn_banquet_id"></has-error>
                </div>
                <div class="form-group">
                  <label>Transport</label>
                  <select v-model="form.transport_id" id="transport_id" type="text" name="transport_id" placeholder="Name" class="form-control" :class="{ 'is-invalid': form.errors.has('transport_id') }" @change="itemSelect('transport_id')">
                        <option value="">Select Transport</option>
                        <option v-for="(transport,index) in transports" v-bind:key="index" :value="transport.id">
                            {{transport.name}}
                        </option>
                  </select>
                  <has-error :form="form" field="transport_id"></has-error>
                </div>
                <div class="form-group">
                  <label>Booking Date</label>
                  <input v-model="form.booking_date" type="date" name="booking_date" placeholder="Select Date" 
                    class="form-control" :class="{ 'is-invalid': form.errors.has('booking_date') }">
                  <has-error :form="form" field="booking_date"></has-error>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button v-show="!editmode" type="submit" class="btn btn-primary">Create</button>
                <button v-show="editmode" type="submit" class="btn btn-primary">Update</button>
              </div>
              </form>
            </div>
          </div>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
          return{
            loading: true,
            search: '',
            pond:'',
            editmode: false,
            bookings:{},
            huts:{},
            caterings:{},
            decorators:{},
            farmhouses:{},
            hotelrestaurants:{},
            lawnbanquets:{},
            transports:{},
            photographers:{},
            form: new Form({
              id:       '',
              hut_id:     '',
              catering_id:     '',
              decorator_id:     '',
              farm_house_id:     '',
              hotel_restaurant_id:     '',
              lawn_banquet_id:     '',
              photographer_id:     '',
              transport_id:     '',
              booking_date:    '',
            }),
            
            dateForm: new Form({
              startDate: '',
              endDate: ''
            })
          }
        },
        methods:{
          getResults(page = 1) {
            this.loading = true;
            let query = this.search;
            if(query == '' && this.dateForm.startDate == "" && this.dateForm.endDate == ""){
              axios.get('api/booking?paginate=1&q='+query+'&page=' + page)
                .then(response => {
                  this.bookings = response.data;
                  this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
            else if(this.dateForm.startDate != "" || this.dateForm.endDate != ""){
              this.dateFilter(page);
            }
            else{
              axios.get('api/findbooking?q='+query+'&page=' + page).then(({data})=>{
                this.bookings = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
          },
          dateFilter(page){
            this.loading = true;
            this.dateForm.post('api/date_search_booking?page='+page)
              .then(response => {
                this.bookings = response.data;
                this.loading = false;
            }).catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
            });
          },
          itemSelect(item){
            var data = this.form[item];
            this.form.reset();
            this.form[item] = data;
          },
          ImageRender(image){
            return process.env.MIX_DOMAIN+image;
          },
          InitializeFilePond(){
            const inputElement = document.querySelector('input[type="file"]');
            this.pond = FilePond.create(inputElement,{
              credits: false,
            });
          },
          SetFilePond(){
            var fileId = Date.now();
            FilePond.setOptions({
              server: {
                process: {
                  url: 'api/file_upload?fileId='+fileId,
                  method: 'POST',
                  headers: {
                    'X-XSRF-TOKEN':document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                  },
                  onload: (response) => {
                    this.form.image = response;
                  },
                },
                revert: {
                  url: 'api/file_delete?fileId='+fileId,
                  method: 'POST',
                  headers: {
                    'X-XSRF-TOKEN':document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                  },
                  onload: (response) => {
                    this.form.image = '';
                  },
                }
              }
            });
          },
          AddBookingModal(){
            this.SetFilePond();
            this.form.reset();
            this.editmode = false;
            this.form.image = '';
            this.pond.removeFiles();
            $('#bookingModal').modal('show');
          },
          EditBookingModal(booking){
            this.SetFilePond();
            this.form.fill(booking);
            this.editmode = true;
            this.form.image = '';
            this.pond.removeFiles();
            $('#bookingModal').modal('show');
          },
          deleteBooking(id){
            Swal.fire({
              title: 'Are you sure?',
              text: "You won't be able to revert this!",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                  this.form.delete('api/booking/'+id).then(()=>(this.searchit()));
                  Swal.fire(
                    'Deleted!',
                    'Your file has been deleted.',
                    'success'
                  );
                }
            }).catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
              else if(error.response.status != 401){
                Toast.fire({
                  icon: 'error',
                  title: 'Something went wrong'
                });
                this.$Progress.finish();
              }
            });
          },
          loadBooking(){
              axios.get('api/booking?paginate=1').then(({data})=>{
                this.bookings = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
          },
          loadData(){
            axios.get('api/get_data').then(({data})=>{
                this.huts = data.huts;
                this.caterings = data.caterings;
                this.decorators = data.decorators;
                this.photographers = data.photographers;
                this.farmhouses = data.farmhouses;
                this.hotelrestaurants = data.hotelrestaurants;
                this.lawnbanquets = data.lawnbanquets;
                this.transports = data.transports;
            }).catch((error)=>{
                if(error.response.status == 401){
                    location.reload();
                }
            });
          },
          createBooking(){
            this.$Progress.start();
            this.form.post('api/booking')
            .then(()=>{
              this.loadBooking();
              $('#bookingModal').modal('hide');
              Toast.fire({
                icon: 'success',
                title: 'Booking Created Successfully'
              });
              this.$Progress.finish();
            })
            .catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
              else if(error.response.status != 401){
                Toast.fire({
                  icon: 'error',
                  title: 'Something went wrong'
                });
                this.$Progress.finish();
              }
            });
          },
          updateBooking(){
            this.$Progress.start();
            this.form.put('api/booking/'+this.form.id)
            .then(()=>{
              $('#bookingModal').modal('hide');
              Toast.fire({
                icon: 'success',
                title: 'Booking Updated Successfully'
              });
              this.$Progress.finish();
            }).then(()=>(this.searchit())).
            catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
              else if(error.response.status != 401){
                Toast.fire({
                  icon: 'error',
                  title: 'Something went wrong'
                });
                this.$Progress.finish();
              }
            });
          },
          searchit(){
            this.loading = true;
            let query = this.search;
            this.dateForm.startDate = '';
            this.dateForm.endDate = '';
            if(query == ''){
              this.loadBooking();
            }
            else{
              axios.get('api/findbooking?q='+query).then(({data})=>{
                this.bookings = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
          },
        },
        mounted() {
            this.loadBooking();
            this.loadData();
            this.InitializeFilePond();
            if(!this.$gate.canViewBooking()){
              this.$router.push('NotFound');
            }
        }
    };
</script>
