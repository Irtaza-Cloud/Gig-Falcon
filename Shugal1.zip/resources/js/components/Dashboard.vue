<template>
    <div class="container">
      <loading :active.sync="isLoading" :is-full-page="true"></loading>
      <div class="row ml-1">
          <h2 class="mt-3">Dashboard</h2>
      </div>
      <div class="row">
        <div class="col-lg-3 col-12">
          <!-- small box -->
          <div class="small-box bg-info">
            <div class="inner">
              <h3>
                <number
                  ref="number1"
                  :from="0"
                  :to="huts"
                  :duration="1"
                  :delay="2"
                  easing="Power2.easeOut"/>
              </h3>

              <p>Huts</p>
            </div>
            <div class="icon">
              <i class="ion ion-home"></i>
            </div>
            <router-link :to="{ name: 'hut'}" class="small-box-footer">
              More info <i class="fas fa-arrow-circle-right"></i>
            </router-link>
          </div>
        </div>
        <div class="col-lg-3 col-12">
          <!-- small box -->
          <div class="small-box bg-success">
            <div class="inner">
              <h3>
                <number
                  ref="number1"
                  :from="0"
                  :to="farm_houses"
                  :duration="1"
                  :delay="2"
                  easing="Power2.easeOut"/>
              </h3>

              <p>Farm Houses</p>
            </div>
            <div class="icon">
              <i class="ion ion-home"></i>
            </div>
            <router-link :to="{ name: 'farmhouse'}" class="small-box-footer">
              More info <i class="fas fa-arrow-circle-right"></i>
            </router-link>
          </div>
        </div>
        <div class="col-lg-3 col-12">
          <!-- small box -->
          <div class="small-box bg-warning">
            <div class="inner">
              <h3>
                <number
                  ref="number1"
                  :from="0"
                  :to="caterings"
                  :duration="1"
                  :delay="2"
                  easing="Power2.easeOut"/>
              </h3>

              <p>Catering</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <router-link :to="{ name: 'catering'}" class="small-box-footer">
              More info <i class="fas fa-arrow-circle-right"></i>
            </router-link>
          </div>
        </div>
        <div class="col-lg-3 col-12">
          <!-- small box -->
          <div class="small-box bg-danger">
            <div class="inner">
              <h3>
                <number
                  ref="number1"
                  :from="0"
                  :to="decorators"
                  :duration="1"
                  :delay="2"
                  easing="Power2.easeOut"/>
              </h3>

              <p>Decorators</p>
            </div>
            <div class="icon">
              <i class="fas fa-holly-berry"></i>
            </div>
            <router-link :to="{ name: 'decorator'}" class="small-box-footer">
              More info <i class="fas fa-arrow-circle-right"></i>
            </router-link>
          </div>
        </div>
        <div class="col-lg-3 col-12">
          <!-- small box -->
          <div class="small-box bg-success">
            <div class="inner">
              <h3>
                <number
                  ref="number1"
                  :from="0"
                  :to="photographers"
                  :duration="1"
                  :delay="2"
                  easing="Power2.easeOut"/>
              </h3>

              <p>Photographer</p>
            </div>
            <div class="icon">
              <i class="fas fa-camera"></i>
            </div>
            <router-link :to="{ name: 'photographer'}" class="small-box-footer">
              More info <i class="fas fa-arrow-circle-right"></i>
            </router-link>
          </div>
        </div>
        <div class="col-lg-3 col-12">
          <!-- small box -->
          <div class="small-box bg-warning">
            <div class="inner">
              <h3>
                <number
                  ref="number1"
                  :from="0"
                  :to="hotel_restaurants"
                  :duration="1"
                  :delay="2"
                  easing="Power2.easeOut"/>
              </h3>

              <p>Hotel Restaurants</p>
            </div>
            <div class="icon">
              <i class="fas fa-building"></i>
            </div>
            <router-link :to="{ name: 'hotelrestaurant'}" class="small-box-footer">
              More info <i class="fas fa-arrow-circle-right"></i>
            </router-link>
          </div>
        </div>
        <div class="col-lg-3 col-12">
          <!-- small box -->
          <div class="small-box bg-danger">
            <div class="inner">
              <h3>
                <number
                  ref="number1"
                  :from="0"
                  :to="lawn_banquets"
                  :duration="1"
                  :delay="2"
                  easing="Power2.easeOut"/>
              </h3>

              <p>Lawn Banquets</p>
            </div>
            <div class="icon">
              <i class="fas fa-hotel"></i>
            </div>
            <router-link :to="{ name: 'lawnbanquet'}" class="small-box-footer">
              More info <i class="fas fa-arrow-circle-right"></i>
            </router-link>
          </div>
        </div>
        <div class="col-lg-3 col-12">
          <!-- small box -->
          <div class="small-box bg-info">
            <div class="inner">
              <h3>
                <number
                  ref="number1"
                  :from="0"
                  :to="transports"
                  :duration="1"
                  :delay="2"
                  easing="Power2.easeOut"/>
              </h3>

              <p>Transports</p>
            </div>
            <div class="icon">
              <i class="fas fa-bus"></i>
            </div>
            <router-link :to="{ name: 'transport'}" class="small-box-footer">
              More info <i class="fas fa-arrow-circle-right"></i>
            </router-link>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
    export default {
        data(){
            return{
                huts:0,
                hotel_restaurants:0,
                lawn_banquets:0,
                farm_houses:0,
                caterings:0,
                decorators:0,
                photographers:0,
                transports:0,
                isLoading: true,
            }
        },
        methods:{
          loadNumber(){
            axios.get('api/get_number')
            .then(({data})=>{
              this.huts = data.huts
              this.hotel_restaurants = data.hotel_restaurants
              this.lawn_banquets = data.lawn_banquets
              this.farm_houses = data.farm_houses
              this.caterings = data.caterings
              this.decorators = data.decorators
              this.photographers = data.photographers
              this.transports = data.transports
              this.isLoading = false;
            });
          }
        },
        mounted() {
          this.loadNumber();
        }
    };
</script>
