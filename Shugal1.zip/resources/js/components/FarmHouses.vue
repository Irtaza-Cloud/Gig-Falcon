<template>
    <div class="container" v-if="$gate.canViewFarmHouse()">
        <div class="row">
          <div class="col-md-12 mt-3">
            <div class="card">
              <div class="card-header">
                <h2>FarmHouse Details</h2>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-md-5 col-12">
                    <div class="form-group">
                      <input v-model="dateForm.startDate" class="form-control" id="startDate" type="date" name="startDate" @change="dateFilter(1)">
                    </div>
                  </div>
                  <div class="col-md-5 col-12">
                    <div class="form-group">
                      <input v-model="dateForm.endDate" class="form-control" id="endDate" type="date" name="endDate" @change="dateFilter(1)">
                    </div>
                  </div>
                  <div class="col-md-2 col-12">
                    <div class="form-group">
                      <button class="btn btn-success xs form-control" @click="dateFilter(1)">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title mt-2"></h3>
                  <button v-if="$gate.canCreateFarmHouse()" class="btn btn-success xs" id="add_farmhouse" @click="AddFarmHouseModal">
                      <i class="fas fa-plus fa-lg"></i>
                  </button>
                <div class="card-tools mt-2">
                  <div class="input-group input-group-sm" style="width: 350px;">
                    <input v-model="search" type="text" name="table_search" class="form-control float-right" id="table_search" placeholder="Search" @keyup.enter="searchit">
                    <div class="input-group-append ml-2">
                      <button class="btn btn-primary" id="s_btn" @click="searchit">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>

                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Image</th>
                      <th>Area</th>
                      <th>Rent Per Slot</th>
                      <th>Contact</th>
                      <th>Created At</th>
                      <th>Updated</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-show="loading" class="text-center">
                      <td colspan="8">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="margin: auto; background: none; display: block; shape-rendering: auto; animation-play-state: running; animation-delay: 0s;" width="100px" height="100px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
                          <path d="M10 50A40 40 0 0 0 90 50A40 41.4 0 0 1 10 50" fill="#215d38" stroke="none" style="animation-play-state: running; animation-delay: 0s;">
                            <animateTransform attributeName="transform" type="rotate" dur="0.8928571428571428s" repeatCount="indefinite" keyTimes="0;1" values="0 50 50.7;360 50 50.7" style="animation-play-state: running; animation-delay: 0s;"></animateTransform>
                          </path>
                        </svg>
                      </td>
                    </tr>
                    <tr v-show="!loading" v-for="(farmhouse,index) in farmhouses.data" v-bind:key="index">
                      <td>{{farmhouse.id}}</td>
                      <td>{{farmhouse.name}}</td>
                      <td style="width:10%;" @click="OpenImage(farmhouse.image)"><img :src="ImageRender(farmhouse.image)" style="width:50%;"></td>
                      <td>{{farmhouse.area}}</td>
                      <td>{{farmhouse.rent_per_slot}}</td>
                      <td>{{farmhouse.contact}}</td>
                      <td>{{farmhouse.created_at | myDate}}</td>
                      <td>{{farmhouse.updated_at | humanDate}}</td>
                      <td>
                          <a v-if="$gate.canUpdateFarmHouse()" href="javascript:void(0)" @click="EditFarmHouseModal(farmhouse)">
                            <i class="fas fa-edit blue ml-1"></i>
                          </a>
                          <a v-if="$gate.canDeleteFarmHouse()" href="javascript:void(0)" @click="deleteFarmHouse(farmhouse.id)"><i class="fas fa-trash red ml-1"></i></a>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                <pagination :data="farmhouses" @pagination-change-page="getResults"></pagination>
              </div>
            </div>
            <!-- /.card -->
          </div>
        </div>
        <div class="modal fade" id="farmhouseModal" tabindex="-1" role="dialog" aria-labelledby="farmhouseModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 v-show="!editmode" class="modal-title" id="farmhouseModalLabel">Add New FarmHouse</h5>
                <h5 v-show="editmode" class="modal-title" id="farmhouseModalLabel">Update FarmHouse</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <form @submit.prevent="editmode ? updateFarmHouse() : createFarmHouse()">
              <div class="modal-body">
                <div class="form-group">
                  <label>Name</label>
                  <input v-model="form.name" id="name" type="text" name="name" placeholder="Name"
                    class="form-control" :class="{ 'is-invalid': form.errors.has('name') }">
                  <has-error :form="form" field="name"></has-error>
                </div>
                <div class="form-group">
                  <label>Image</label>
                  <input id="image" type="file" name="image"
                    :class="{ 'is-invalid': form.errors.has('image') }">
                  <has-error :form="form" field="image"></has-error>
                </div>
                <div class="form-group">
                  <label>City</label>
                  <input v-model="form.city" id="city" type="text" name="city" placeholder="Enter City"
                    class="form-control" :class="{ 'is-invalid': form.errors.has('city') }">
                  <has-error :form="form" field="city"></has-error>
                </div>
                <div class="form-group">
                  <label>Address</label>
                  <textarea v-model="form.address" id="address" type="text" name="address" placeholder="Enter Address"
                    class="form-control" :class="{ 'is-invalid': form.errors.has('address') }"></textarea>
                  <has-error :form="form" field="address"></has-error>
                </div>
                <div class="form-group">
                  <label>Description</label>
                  <textarea v-model="form.description" id="description" type="text" name="description" placeholder="Enter Description"
                    class="form-control" :class="{ 'is-invalid': form.errors.has('description') }"></textarea>
                  <has-error :form="form" field="description"></has-error>
                </div>
                <div class="form-group">
                  <label>Service Hours</label>
                  <select v-model="form.service_hours_type" id="service_hours" type="service_hours" name="service_hours" placeholder="Enter Rooms" 
                    class="form-control" :class="{ 'is-invalid': form.errors.has('service_hours') }" @change="changeServiceHours()">
                    <option value="24 hours">24 Hours</option>
                    <option value="12 hours">12 Hours</option>
                    <option value="specific">Specific</option>
                  </select>
                  <has-error :form="form" field="service_hours"></has-error>
                  <div v-if="specific_service_hours_show" class="d-flex mt-2">
                    <select v-model="service_hours.from" class="form-control" name="" id="" @change="serviceHoursFrom()">
                      <option value="12:00 am">12:00 am</option>
                      <option value="01:00 am">01:00 am</option>
                      <option value="02:00 am">02:00 am</option>
                      <option value="03:00 am">03:00 am</option>
                      <option value="04:00 am">04:00 am</option>
                      <option value="05:00 am">05:00 am</option>
                      <option value="06:00 am">06:00 am</option>
                      <option value="07:00 am">07:00 am</option>
                      <option value="08:00 am">08:00 am</option>
                      <option value="09:00 am">09:00 am</option>
                      <option value="10:00 am">10:00 am</option>
                      <option value="11:00 am">11:00 am</option>
                      <option value="12:00 pm">12:00 pm</option>
                      <option value="01:00 pm">01:00 pm</option>
                      <option value="02:00 pm">02:00 pm</option>
                      <option value="03:00 pm">03:00 pm</option>
                      <option value="04:00 pm">04:00 pm</option>
                      <option value="05:00 pm">05:00 pm</option>
                      <option value="06:00 pm">06:00 pm</option>
                      <option value="07:00 pm">07:00 pm</option>
                      <option value="08:00 pm">08:00 pm</option>
                      <option value="09:00 pm">09:00 pm</option>
                      <option value="10:00 pm">10:00 pm</option>
                      <option value="11:00 pm">11:00 pm</option>
                    </select>
                    <select v-model="service_hours.to" class="form-control ml-2" name="" id="" @change="serviceHoursTo()">
                      <option value="12:00 am">12:00 am</option>
                      <option value="01:00 am">01:00 am</option>
                      <option value="02:00 am">02:00 am</option>
                      <option value="03:00 am">03:00 am</option>
                      <option value="04:00 am">04:00 am</option>
                      <option value="05:00 am">05:00 am</option>
                      <option value="06:00 am">06:00 am</option>
                      <option value="07:00 am">07:00 am</option>
                      <option value="08:00 am">08:00 am</option>
                      <option value="09:00 am">09:00 am</option>
                      <option value="10:00 am">10:00 am</option>
                      <option value="11:00 am">11:00 am</option>
                      <option value="12:00 pm">12:00 pm</option>
                      <option value="01:00 pm">01:00 pm</option>
                      <option value="02:00 pm">02:00 pm</option>
                      <option value="03:00 pm">03:00 pm</option>
                      <option value="04:00 pm">04:00 pm</option>
                      <option value="05:00 pm">05:00 pm</option>
                      <option value="06:00 pm">06:00 pm</option>
                      <option value="07:00 pm">07:00 pm</option>
                      <option value="08:00 pm">08:00 pm</option>
                      <option value="09:00 pm">09:00 pm</option>
                      <option value="10:00 pm">10:00 pm</option>
                      <option value="11:00 pm">11:00 pm</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label>Area (Sq.ft)</label>
                  <input v-model="form.area" id="area" type="number" name="area" placeholder="Enter Area"
                    class="form-control" :class="{ 'is-invalid': form.errors.has('area') }">
                  <has-error :form="form" field="area"></has-error>
                </div>
                <div class="form-group">
                  <label>No Of Floors</label>
                  <input v-model="form.no_of_floors" id="no_of_floors" type="number" name="no_of_floors" placeholder="Enter No Of Floors"
                    class="form-control" :class="{ 'is-invalid': form.errors.has('no_of_floors') }">
                  <has-error :form="form" field="no_of_floors"></has-error>
                </div>
                <div class="form-group">
                  <label>No Of Rooms</label>
                  <input v-model="form.no_of_rooms" id="no_of_rooms" type="number" name="no_of_rooms" placeholder="Enter No Of Rooms"
                    class="form-control" :class="{ 'is-invalid': form.errors.has('no_of_rooms') }">
                  <has-error :form="form" field="no_of_rooms"></has-error>
                </div>
                <div class="form-group">
                  <label>Slot</label>
                  <select v-model="form.slots" id="slots" type="text" name="slots" placeholder="Enter Tag Line"
                    class="form-control" :class="{ 'is-invalid': form.errors.has('slots') }">
                    <option value="01 hour">01 hour</option>
                    <option value="02 hours">02 hours</option>
                    <option value="03 hours">03 hours</option>
                    <option value="04 hours">04 hours</option>
                    <option value="05 hours">05 hours</option>
                    <option value="06 hours">06 hours</option>
                    <option value="07 hours">07 hours</option>
                    <option value="08 hours">08 hours</option>
                    <option value="09 hours">09 hours</option>
                    <option value="10 hours">10 hours</option>
                    <option value="11 hours">11 hours</option>
                    <option value="12 hours">12 hours</option>
                    <option value="13 hours">13 hours</option>
                    <option value="14 hours">14 hours</option>
                    <option value="15 hours">15 hours</option>
                    <option value="16 hours">16 hours</option>
                    <option value="17 hours">17 hours</option>
                    <option value="18 hours">18 hours</option>
                    <option value="19 hours">19 hours</option>
                    <option value="20 hours">20 hours</option>
                    <option value="21 hours">21 hours</option>
                    <option value="22 hours">22 hours</option>
                    <option value="23 hours">23 hours</option>
                    <option value="24 hours">24 hours</option>
                  </select>
                  <has-error :form="form" field="slot"></has-error>
                </div>
                <div class="form-group">
                  <label>Rent Per Slot</label>
                  <input v-model="form.rent_per_slot" id="rent_per_slot" type="text" name="rent_per_slot" placeholder="Enter Rent Per Slot"
                    class="form-control" :class="{ 'is-invalid': form.errors.has('rent_per_slot') }">
                  <has-error :form="form" field="rent_per_slot"></has-error>
                </div>
                <div class="form-group">
                  <label>Rent Per Day</label>
                  <input v-model="form.rent_per_day" id="rent_per_day" type="text" name="rent_per_day" placeholder="Enter Rent Per Day"
                    class="form-control" :class="{ 'is-invalid': form.errors.has('rent_per_day') }">
                  <has-error :form="form" field="rent_per_day"></has-error>
                </div>
                <div class="form-group">
                  <label>Facilities</label>
                  <div class="d-flex mt-2">
                    <div class="col-md-2">
                      <label>Kitchen</label>
                    </div>
                    <div class="col-md-10">
                      <input v-model="facilities.kitchen" id="decor_packages" type="checkbox" name="decor_packages" placeholder="Enter Tag Line" class="form-control" :class="{ 'is-invalid': form.errors.has('decor_packages') }" @change="decorPackageSelect()">
                    </div>
                  </div>
                  <div class="d-flex mt-2">
                    <div class="col-md-2">
                      <label>Parking</label>
                    </div>
                    <div class="col-md-10">
                      <input v-model="facilities.parking" id="decor_packages" type="checkbox" name="decor_packages" placeholder="Enter Tag Line" class="form-control" :class="{ 'is-invalid': form.errors.has('decor_packages') }" @change="decorPackageSelect()">
                    </div>
                  </div>
                  <div class="d-flex mt-2">
                    <div class="col-md-2">
                      <label>Air Conditioning</label>
                    </div>
                    <div class="col-md-10">
                      <input v-model="facilities.air_conditioning" id="decor_packages" type="checkbox" name="decor_packages" placeholder="Enter Tag Line" class="form-control" :class="{ 'is-invalid': form.errors.has('decor_packages') }" @change="decorPackageSelect()">
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <label>Contact</label>
                  <input v-model="form.contact" type="number" name="contact" placeholder="Enter Contact Number" 
                    class="form-control" :class="{ 'is-invalid': form.errors.has('contact') }">
                  <has-error :form="form" field="contact"></has-error>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button v-show="!editmode" type="submit" class="btn btn-primary">Create</button>
                <button v-show="editmode" type="submit" class="btn btn-primary">Update</button>
              </div>
              </form>
            </div>
          </div>
        </div>

        <div class="modal fade" id="imageModal" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="imageModalLabel">Image</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="form-group">
                  <img class="w-100" :src="open_image" alt="">
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
          return{
            days:[
              '01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31'
            ],
            months:[
              'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'
            ],
            day1:'',
            day2:'',
            month:'',
            page:1,
            loading: true,
            search: '',
            pond:'',
            editmode: false,
            farmhouses:{},
            open_image:'',
            form: new Form({
              id:       '',
              name:     '',
              image:    '',
              address:'',
              city:'',
              description:'',
              service_hours:'12 hours',
              service_hours_type:'12 hours',
              area:'',
              no_of_floors:'',
              no_of_rooms: '',
              slots:'04 hours',
              rent_per_slot:'',
              rent_per_day:'',
              facilities:'',
              contact:'',
            }),
            
            dateForm: new Form({
              startDate: '',
              endDate: ''
            }),
            specific_service_hours_show: false,
            service_hours:{
              from:'09:00 am',
              to:'06:00 pm',
            },
            facilities:{
              air_conditioning:false,
              kitchen:false,
              parking:false,
            },
          }
        },
        methods:{
          decorPackageSelect(){
            var air_conditioning = this.facilities.air_conditioning?'air_conditioning,':'';
            var kitchen = this.facilities.kitchen?'kitchen,':'';
            var parking = this.facilities.parking?'parking,':'';
            this.form.facilities =  air_conditioning + kitchen + parking;
          },
          serviceHoursFrom(){
            this.form.service_hours = this.service_hours.from+' to '+this.service_hours.to;
          },
          serviceHoursTo(){
            this.form.service_hours = this.service_hours.from+' to '+this.service_hours.to;
          },
          changeServiceHours(){
            if(this.form.service_hours_type == '12 hours'){
              this.form.service_hours = '12 hours';
              this.specific_service_hours_show = false;
            }
            else if(this.form.service_hours_type == '24 hours'){
              this.form.service_hours = '24 hours';
              this.specific_service_hours_show = false; 
            }
            else{
              this.form.service_hours_type = 'specific' 
              this.specific_service_hours_show = true; 
              var service_hours = this.form.service_hours.split(' to ');
              if(service_hours.length > 1){
                this.service_hours.from = service_hours[0];
                this.service_hours.to = service_hours[1];
              }
              this.form.service_hours = this.service_hours.from+' to '+this.service_hours.to;
            }
          },
          OpenImage(image){
            $('#imageModal').modal('show');
            this.open_image = window.domain_url+'/'+image;
          },
          getResults(page = 1) {
            this.loading = true;
            this.page = page;
            let query = this.search;
            if(query == '' && this.dateForm.startDate == "" && this.dateForm.endDate == ""){
              axios.get('api/farmhouse?paginate=1&q='+query+'&page=' + page)
                .then(response => {
                  this.farmhouses = response.data;
                  this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
            else if(this.dateForm.startDate != "" || this.dateForm.endDate != ""){
              this.dateFilter(page);
            }
            else{
              axios.get('api/findfarmhouse?q='+query+'&page=' + page).then(({data})=>{
                this.farmhouses = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
          },
          dateFilter(page){
            this.loading = true;
            this.dateForm.post('api/date_search_farmhouse?page='+page)
              .then(response => {
                this.farmhouses = response.data;
                this.loading = false;
            }).catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
            });
          },
          ImageRender(image){
            return window.domain_url+'/'+image;
          },
          InitializeFilePond(){
            const inputElement = document.querySelector('input[type="file"]');
            this.pond = FilePond.create(inputElement,{
              credits: false,
            });
          },
          SetFilePond(){
            var fileId = Date.now();
            FilePond.setOptions({
              server: {
                process: {
                  url: 'api/file_upload?fileId='+fileId,
                  method: 'POST',
                  headers: {
                    'X-XSRF-TOKEN':document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                  },
                  onload: (response) => {
                    this.form.image = response;
                  },
                },
                revert: {
                  url: 'api/file_delete?fileId='+fileId,
                  method: 'POST',
                  headers: {
                    'X-XSRF-TOKEN':document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                  },
                  onload: (response) => {
                    this.form.image = '';
                  },
                }
              }
            });
          },
          AddFarmHouseModal(){
            this.SetFilePond();
            this.form.reset();
            this.editmode = false;
            this.form.image = '';
            this.pond.removeFiles();
            $('#farmhouseModal').modal('show');
          },
          EditFarmHouseModal(farmhouse){
            this.SetFilePond();
            this.form.fill(farmhouse);
            Object.keys(this.facilities).forEach(v => this.facilities[v] = false);
            this.form.service_hours_type = farmhouse.service_hours;
            this.changeServiceHours();
            var facilities = farmhouse.facilities.split(',');
            for(var i=0; i<facilities.length; i++){
              this.facilities[''+facilities[i]+''] = true;
            }
            this.editmode = true;
            this.form.image = '';
            this.pond.removeFiles();
            $('#farmhouseModal').modal('show');
          },
          deleteFarmHouse(id){
            Swal.fire({
              title: 'Are you sure?',
              text: "You won't be able to revert this!",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                  this.form.delete('api/farmhouse/'+id).then(()=>(this.searchit()));
                  Swal.fire(
                    'Deleted!',
                    'Your file has been deleted.',
                    'success'
                  );
                }
            }).catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
              else if(error.response.status != 401){
                Toast.fire({
                  icon: 'error',
                  title: 'Something went wrong'
                });
                this.$Progress.finish();
              }
            });
          },
          loadFarmHouse(){
              axios.get('api/farmhouse?paginate=1').then(({data})=>{
                this.farmhouses = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
          },
          createFarmHouse(){
            this.$Progress.start();
            this.form.post('api/farmhouse')
            .then(()=>{
              this.loadFarmHouse();
              $('#farmhouseModal').modal('hide');
              Toast.fire({
                icon: 'success',
                title: 'FarmHouse Created Successfully'
              });
              this.$Progress.finish();
            })
            .catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
              else if(error.response.status != 401){
                Toast.fire({
                  icon: 'error',
                  title: 'Something went wrong'
                });
                this.$Progress.finish();
              }
            });
          },
          refresh_data(){
            if(this.search != ""){
              console.log('if');
              this.searchit();
            }
            else{
              console.log('else');
              this.getResults(this.page);
            }
          },
          updateFarmHouse(){
            this.$Progress.start();
            this.form.put('api/farmhouse/'+this.form.id)
            .then(()=>{
              $('#farmhouseModal').modal('hide');
              Toast.fire({
                icon: 'success',
                title: 'FarmHouse Updated Successfully'
              });
              this.$Progress.finish();
            }).then(()=>{
              this.refresh_data();
            }).
            catch((error)=>{
              if(error.response.status == 401){
                location.reload();
              }
              else if(error.response.status != 401){
                Toast.fire({
                  icon: 'error',
                  title: 'Something went wrong'
                });
                this.$Progress.finish();
              }
            });
          },
          searchit(){
            this.loading = true;
            let query = this.search;
            this.dateForm.startDate = '';
            this.dateForm.endDate = '';
            if(query == ''){
              this.loadFarmHouse();
            }
            else{
              axios.get('api/findfarmhouse?q='+query).then(({data})=>{
                this.farmhouses = data;
                this.loading = false;
              }).catch((error)=>{
                if(error.response.status == 401){
                  location.reload();
                }
              });
            }
          },
        },
        mounted() {
            this.loadFarmHouse();
            this.InitializeFilePond();
            if(!this.$gate.canViewFarmHouse()){
              this.$router.push('NotFound');
            }
        }
    };
</script>
