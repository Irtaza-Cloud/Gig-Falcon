<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBookingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bookings', function (Blueprint $table) {
            $table->id();
            $table->integer('user_id');
            $table->integer('hut_id')->nullable();
            $table->integer('farm_house_id')->nullable();
            $table->integer('catering_id')->nullable();
            $table->integer('decorator_id')->nullable();
            $table->integer('hotel_restaurant_id')->nullable();
            $table->integer('photographer_id')->nullable();
            $table->integer('lawn_banquet_id')->nullable();
            $table->integer('transport_id')->nullable();
            $table->string('booking_date');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bookings');
    }
}
