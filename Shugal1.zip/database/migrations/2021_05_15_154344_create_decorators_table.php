<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDecoratorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('decorators', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('image');
            $table->text('address');
            $table->text('description');
            $table->string('service_hours');
            $table->string('specialities')->nullable();
            $table->string('slots')->nullable();
            $table->string('rent_per_slot')->nullable();
            $table->string('contact')->nullable();
            $table->float('rating')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('decorators');
    }
}
