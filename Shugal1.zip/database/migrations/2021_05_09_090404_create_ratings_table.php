<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRatingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ratings', function (Blueprint $table) {
            $table->id();
            $table->integer('user_id');
            $table->integer('hut_id')->nullable();
            $table->integer('catering_id')->nullable();
            $table->integer('decorator_id')->nullable();
            $table->integer('photographer_id')->nullable();
            $table->integer('hotel_restaurant_id')->nullable();
            $table->integer('lawn_banquet_id')->nullable();
            $table->integer('farm_house_id')->nullable();
            $table->integer('transport_id')->nullable();
            $table->float('rating');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ratings');
    }
}
