<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCateringsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('caterings', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('image');
            $table->text('address');
            $table->text('description');
            $table->string('service_hours');
            $table->string('seating_capacity')->nullable();
            $table->string('specialities')->nullable();
            $table->string('minimum_servings')->nullable();
            $table->string('charge_per_person')->nullable();
            $table->string('rent_per_day')->nullable();
            $table->string('contact')->nullable();
            $table->float('rating')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('caterings');
    }
}
