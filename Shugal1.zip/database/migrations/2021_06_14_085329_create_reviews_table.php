<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateReviewsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('reviews', function (Blueprint $table) {
            $table->id();
            $table->integer('sender_id');
            $table->integer('receiver_id');
            $table->integer('hut_id')->nullable();
            $table->integer('farm_house_id')->nullable();
            $table->integer('catering_id')->nullable();
            $table->integer('decorator_id')->nullable();
            $table->integer('hotel_restaurant_id')->nullable();
            $table->integer('photographer_id')->nullable();
            $table->integer('lawn_banquet_id')->nullable();
            $table->integer('transport_id')->nullable();
            $table->text('review');
            $table->boolean('like')->default(0);
            $table->boolean('reply')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('reviews');
    }
}
