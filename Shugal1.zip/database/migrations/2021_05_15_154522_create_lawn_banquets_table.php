<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLawnBanquetsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('lawn_banquets', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('image');
            $table->string('address');
            $table->text('description');
            $table->string('service_hours');
            $table->string('seating_capacity')->nullable();
            $table->string('decor_packages')->nullable();
            $table->string('minimum_guests')->nullable();
            $table->string('slots')->nullable();
            $table->string('rent_per_slot')->nullable();
            $table->string('contact')->nullable();
            $table->float('rating')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('lawn_banquets');
    }
}
