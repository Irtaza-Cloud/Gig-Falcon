<?php

use Illuminate\Database\Seeder;
use Faker\Generator as Faker;
use App\User;
use App\Role;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run(Faker $faker)
    {
        $role = Role::create([
            'name'=>'Administrator',
            'permissions'=>'{"view_user":true,"create_user":true,"update_user":true,"delete_user":true,"view_role":true,"create_role":true,"update_role":true,"delete_role":true}',
        ]);

    	$user = User::create([
            'name'=>'Administrator',
            'email'=>'admin@admin.com',
            'password'=>'$2y$10$AplUG1Kikj8STfeigGkMjeBibGJS0Xq8bEQjzHCZMPaW5eZ6XJcvm',
        ]);

        $user->roles()->attach($role->id);
    }
}
