<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('auth/login', 'API\AuthController@login');
Route::post('auth/register', 'API\AuthController@register');
Route::post('auth/forgot_password', 'API\AuthController@forgot_password');
Route::get('invalid_token','API\AuthController@invalid_token')->name('invalid_token');
Route::post('file_upload','API\UploadController@file_upload')->name('file_upload');
Route::post('file_delete','API\UploadController@file_delete')->name('file_delete');

Route::group(['middleware'=>'auth:api'],function(){

	Route::get('validate-token','API\AuthController@validate_token');

    Route::get("profile", [HomeController::class, 'myprofile']);

    Route::post("gig", 'PostController@store');

    Route::put('profile', 'UserController@update');


	Route::apiResources(['user'=>'API\UserController']);
	Route::apiResources(['role'=>'API\RoleController']);
	Route::apiResources(['graphic_design'=>'API\GraphicDesignCon']);
	Route::apiResources(['booking'=>'API\BookingController']);
	Route::apiResources(['rating'=>'API\RatingController']);
	Route::apiResources(['checkinout'=>'API\CheckInOutController']);
	Route::apiResources(['transport'=>'API\TransportController']);
	Route::apiResources(['photographer'=>'API\PhotographerController']);
	Route::apiResources(['decorator'=>'API\DecoratorController']);
	Route::apiResources(['catering'=>'API\CateringController']);
	Route::apiResources(['farmhouse'=>'API\FarmHouseController']);
	Route::apiResources(['hotelrestaurant'=>'API\HotelRestaurantController']);
	Route::apiResources(['lawnbanquet'=>'API\LawnBanquetController']);
	Route::apiResources(['review'=>'API\ReviewController']);
	Route::apiResources(['transaction'=>'API\TransactionController']);

	Route::post('date_search_user','API\UserController@date_search')->name('user.date_search');
	Route::post('date_search_role','API\RoleController@date_search')->name('role.date_search');
	Route::post('date_search_hut','API\HutController@date_search')->name('hut.date_search');
	Route::post('date_search_farmhouse','API\FarmHouseController@date_search');
	Route::post('date_search_hotelrestaurant','API\HotelRestaurantController@date_search');
	Route::post('date_search_lawnbanquet','API\LawnBanquetController@date_search');
	Route::post('date_search_transport','API\TransportController@date_search');
	Route::post('date_search_catering','API\CateringController@date_search');
	Route::post('date_search_decorator','API\DecoratorController@date_search');
	Route::post('date_search_photographer','API\PhotographerController@date_search');

	Route::post('date_search_booking','API\BookingController@date_search')->name('user.date_search');
	Route::post('date_search_checkinout','API\CheckInOutController@date_search')->name('user.date_search');

	Route::get('finduser','API\UserController@search');
	Route::get('findhut','API\HutController@search');
	Route::get('findcatering','API\CateringController@search');
	Route::get('finddecorator','API\DecoratorController@search');
	Route::get('findphotographer','API\PhotographerController@search');
	Route::get('findfarmhouse','API\FarmHouseController@search');
	Route::get('findhotelrestaurant','API\HotelRestaurantController@search');
	Route::get('findlawnbanquet','API\LawnBanquetController@search');
	Route::get('findtransport','API\TransportController@search');

	Route::get('findrating','API\RatingController@search');
	Route::get('findbooking','API\BookingController@search');

	Route::get('get_number','API\UserController@get_number');

	Route::get('huts_list','API\HutController@list');
	Route::get('caterings_list','API\CateringController@list');
	Route::get('decorators_list','API\DecoratorController@list');
	Route::get('hotel_restaurants_list','API\HotelRestaurantController@list');
	Route::get('farm_houses_list','API\FarmHouseController@list');
	Route::get('lawn_banquets_list','API\LawnBanquetController@list');
	Route::get('photographers_list','API\PhotographerController@list');
	Route::get('transports_list','API\TransportController@list');

	Route::get('popular_huts','API\HutController@popular');
	Route::get('popular_farmhouses','API\FarmHouseController@popular');
	Route::get('popular_transports','API\TransportController@popular');
	Route::get('popular_caterings','API\CateringController@popular');
	Route::get('popular_decorators','API\DecoratorController@popular');
	Route::get('popular_photographers','API\PhotographerController@popular');
	Route::get('popular_hotelrestaurants','API\HotelRestaurantController@popular');
	Route::get('popular_lawnbanquets','API\LawnBanquetController@popular');

	Route::get('featured_huts','API\HutController@featured');
	Route::get('featured_farmhouses','API\FarmHouseController@featured');
	Route::get('featured_transports','API\TransportController@featured');
	Route::get('featured_caterings','API\CateringController@featured');
	Route::get('featured_decorators','API\DecoratorController@featured');
	Route::get('featured_photographers','API\PhotographerController@featured');
	Route::get('featured_hotelrestaurants','API\HotelRestaurantController@featured');
	Route::get('featured_lawnbanquets','API\LawnBanquetController@featured');

	Route::post('wishlist','API\UserController@wishlist');
	Route::post('check_availability','API\BookingController@check_availability');
	Route::get('get_data','API\BookingController@get_data');

	Route::get('vendor_dashboard','API\UserController@vendor_dashboard');
	Route::get('today_bookings','API\BookingController@today_bookings');
	Route::get('upcoming_bookings','API\BookingController@upcoming_bookings');
	Route::get('upcoming_bookings','API\BookingController@upcoming_bookings');
	Route::post('cancel_booking','API\BookingController@cancel_booking');
	Route::post('confirm_booking','API\BookingController@confirm_booking');
	Route::post('confirm_all','API\BookingController@confirm_all');
	Route::post('like_review','API\ReviewController@like_review');
	Route::post('review_reply','API\ReviewController@review_reply');
	Route::get('vendor_reviews','API\ReviewController@vendor_reviews');
	Route::get('my_assets','API\UserController@my_assets');

	Route::get('week_earnings','API\TransactionController@week_earnings');
	Route::get('month_earnings','API\TransactionController@month_earnings');
	Route::post('add_to_featured','API\TransactionController@add_to_featured');
});
