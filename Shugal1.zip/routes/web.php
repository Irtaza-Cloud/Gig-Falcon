<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\PostController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::view('/', 'welcome');
Route::get('/home', function () {
    if(Auth::check()){
        return redirect()->route('home');
    }
    return redirect()->route('login');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/profile', 'HomeController@myprofile')->name('profile');
//Route::view('/my-profile', 'HomeController@myprofile');


Route::get('/{any}', 'HomeController@index')->where('any', '.*');
Route::get("profile", [HomeController::class, 'myprofile']);

Route::post('gig',[PostController::class, 'store']) ;


Route::view('gig', 'gig');
Route::post("gig", 'PostController@store');

Route::post('profile', 'AuthController@update_profile');




Route::view('gig', 'gig');
Route::post("profile", [PostController::class, 'store']);


Route::post('forgot_password', 'API\AuthController@forgot_password');

Route::view('hqhq', 'hqhq');
