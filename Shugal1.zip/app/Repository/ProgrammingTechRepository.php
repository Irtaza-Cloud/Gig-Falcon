<?php

namespace App\Repository;

use App\HotelRestaurant;
use Hash;
use DB;
use App\ProgrammingTech;
use App\Repository\RepositoryCRUD;

class ProgrammingTechRepository extends RepositoryCRUD
{
    public function __construct()
    {
        $this->model = 'App\HotelRestaurant';
        $this->db = 'hotel_restaurant';
    }

 	public function search($request){
        return ProgrammingTech::where('name','like','%'.$request->q.'%')
        ->orWhere('address','like','%'.$request->q.'%')
        ->orWhere('description','like','%'.$request->q.'%')
        ->orWhere('service_hours','like','%'.$request->q.'%')
        ->orWhere('seating_capacity','like','%'.$request->q.'%')
        ->orWhere('decor_packages','like','%'.$request->q.'%')
        ->orWhere('minimum_guests','like','%'.$request->q.'%')
        ->orWhere('slots','like','%'.$request->q.'%')
        ->orWhere('rent_per_slot','like','%'.$request->q.'%')
        ->orWhere('rating','like','%'.$request->q.'%')
        ->paginate(10);
    }

    public function popular_hotelrestaurants($request){
        return ProgrammingTech::orderBy('rating','desc')->paginate(10);
    }

    public function get_hotelrestaurants($id){
        try{
            $model_data = $this->model::withCount('check_in')->find($id);
            $rating = Rating::select('rating as user_rating')
                        ->where($this->db.'_id',$id)
                        ->where('user_id',auth()->user()->id)
                        ->first();

            $model_data['user_rating'] = $rating;

        }
        catch(\Exception $exception){
            return response()->json(['error'=>$exception->getMessage()]);
        }
        return $model_data;
    }
}
