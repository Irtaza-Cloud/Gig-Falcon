<?php

namespace App\Repository;

use App\Booking;
use App\Hut;
use App\Catering;
use App\Decorator;
use App\Photographer;
use App\Transport;
use App\FarmHouse;
use App\HotelRestaurant;
use App\LawnBanquet;
use Hash;
use DB;
use App\Repository\RepositoryCRUD;
use Carbon\Carbon;

class BookingRepository extends RepositoryCRUD
{
    public function __construct()
    {
        $this->model = 'App\Booking';
    }

 	public function search($request){
        return Booking::whereHas('huts',function($q)use($request){
            $q->where('name','like','%'.$request->q.'%');
        })->orWhereHas('caterings',function($q)use($request){
            $q->where('name','like','%'.$request->q.'%');
        })->orWhereHas('decorators',function($q)use($request){
            $q->where('name','like','%'.$request->q.'%');
        })->orWhereHas('photographers',function($q)use($request){
            $q->where('name','like','%'.$request->q.'%');
        })->orWhereHas('farmhouses',function($q)use($request){
            $q->where('name','like','%'.$request->q.'%');
        })->orWhereHas('hotelrestaurants',function($q)use($request){
            $q->where('name','like','%'.$request->q.'%');
        })->orWhereHas('lawnbanquets',function($q)use($request){
            $q->where('name','like','%'.$request->q.'%');
        })->orWhereHas('transports',function($q)use($request){
            $q->where('name','like','%'.$request->q.'%');
        })->orWhere('booking_date','like','%'.$request->q.'%')
        ->paginate(10);
    }

    public function get_data(){
        $huts = Hut::all();
        $caterings = Catering::all();
        $decorators = Decorator::all();
        $photographers = Photographer::all();
        $transports = Transport::all();
        $hotelrestaurants = HotelRestaurant::all();
        $farmhouses = Farmhouse::all();
        $lawnbanquets = LawnBanquet::all();
        return [
            'huts'=>$huts,
            'caterings'=>$caterings,
            'decorators'=>$decorators,
            'photographers'=>$photographers,
            'transports'=>$transports,
            'farmhouses'=>$farmhouses,
            'hotelrestaurants'=>$hotelrestaurants,
            'lawnbanquets'=>$lawnbanquets,            
        ];
    }

    public function check_availability($request){
        $data = $request->all();
        $from = Carbon::parse($data['date']);
        $to = $from->endOfMonth();
        // $month = $from->endOfMonth()->month;
        // $month = $month < 10?'0'.$month:$month;
        // $year = $from->endOfMonth()->year;
        // $bookings_days = array(); 
        // for($i=1; $i<=$to->day; $i++){
        //     $day = $i < 10?'0'.$i:$i;
        //     $date = $year.'-'.$month.'-'.$day;
        //     array_push($bookings_days,$date);
        // }
        $bookings = Booking::select('booking_date','time_slot')
        ->whereDate('booking_date','>=', Carbon::parse($data['date']))
        ->whereDate('booking_date','<=', Carbon::parse($to->toDateString()))
        ->get();
        $bookings_made = array();
        for($j=0; $j<count($bookings); $j++){
            array_push($bookings_made,[
                'booking_date'=>$bookings[$j]['booking_date'],
                'time_slot'=>$bookings[$j]['time_slot']
            ]);
        }
        // $bookings_available = array();
        // $bookings_available = array_diff($bookings_days,$bookings_made);
        // return array_values($bookings_available);
        return response()->json($bookings_made);
    }

    public function confirm_booking($request){
        Booking::find($request->booking_id)->update([
            'status'=>'confirmed',
        ]);
        
        return response()->json(['message'=>'Booking confirmed']);
    }

    public function confirm_all($request){
        Booking::where('vendor_id',auth()->user()->id)->update([
            'status'=>'confirmed',
        ]);
        
        return response()->json(['message'=>'Booking confirmed']);
    }

    public function today_bookings(){
        return Booking::where('vendor_id',auth()->user()->id)
        ->whereDate('booking_date','<=',today())
        ->whereDate('booking_date','>=',today())
        ->get();
    }

    public function upcoming_bookings(){
        return Booking::where('vendor_id',auth()->user()->id)
        ->whereDate('booking_date','>=',today())
        ->get();
    }

    public function cancel_booking($request){
        Booking::find($request->booking_id)->update([
            'status'=>'cancelled',
        ]);
        
        return response()->json(['message'=>'Booking cancelled']);
    }
}