<?php

namespace App\Repository;

use App\MusicsAudio;
use Hash;
use DB;
use App\Repository\RepositoryCRUD;

class MusicandAudioRepository extends RepositoryCRUD
{
    public function __construct()
    {
        $this->model = 'App\MusicsAudio';
        $this->db = 'music_audios';
    }

 	public function search($request){
        return MusicsAudio::where('name','like','%'.$request->q.'%')
        ->orWhere('vehicle_name','like','%'.$request->q.'%')
        ->orWhere('vehicle_model','like','%'.$request->q.'%')
        ->orWhere('description','like','%'.$request->q.'%')
        ->orWhere('service_hours','like','%'.$request->q.'%')
        ->orWhere('seating_capacity','like','%'.$request->q.'%')
        ->orWhere('facilities','like','%'.$request->q.'%')
        ->orWhere('rent_per_day','like','%'.$request->q.'%')
        ->orWhere('slots','like','%'.$request->q.'%')
        ->orWhere('rent_per_slot','like','%'.$request->q.'%')
        ->orWhere('rating','like','%'.$request->q.'%')
        ->orWhere('contact','like','%'.$request->q.'%')
        ->paginate(10);
    }

    public function popular_transports($request){
        return MusicsAudio::orderBy('rating','desc')->paginate(10);
    }

    public function get_transports($id){
        try{
            $model_data = $this->model::find($id);
            $rating = Rating::select('rating as user_rating')
                        ->where($this->db.'_id',$id)
                        ->where('user_id',auth()->user()->id)
                        ->first();

            $model_data['user_rating'] = $rating;

        }
        catch(\Exception $exception){
            return response()->json(['error'=>$exception->getMessage()]);
        }
        return $model_data;
    }
}
