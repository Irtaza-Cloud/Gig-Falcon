<?php

namespace App\Repository;

use App\User;
use Illuminate\Http\Request;
use Hash;
use Illuminate\Support\Facades\Storage;
use DB;

class RepositoryCRUD
{
    public $model;
    public $db;

    public function index($request){

        if($request->paginate == 1){
            try{
                $model_data = $this->model::orderBy('id', 'desc')->paginate(10);
            }
            catch(\Exception $exception){
                return response()->json(['error'=>$exception->getMessage()]);
            }
            return $model_data;
        }
        else{
            try{
                $model_data = $this->model::all();
            }
            catch(\Exception $exception){
                return response()->json($exception->getMessage(),500);
            }
            return $model_data;
        }
    }

    public function store($request){

        $data = $request->all();
        try{
            if(array_key_exists('password', $data)){
                $data['password'] = Hash::make($request->password);
            }
            if(array_key_exists('user_id', $data)){
                if(empty($data['user_id'])){
                    $data['user_id'] = auth()->user()->id;
                }
            }

            $model_data = $this->model::create($data);

            if(array_key_exists('role', $data)){
                $model_data->roles()->attach($data['role']);
            }
        }
        catch(\Exception $exception){
            return response()->json(['error'=>$exception->getMessage()],500);
        }
        return $model_data;
    }

    public function find($id){

        try{
            $model_data = $this->model::findOrFail($id);
        }
        catch(\Exception $exception){
            return response()->json(['error'=>$exception->getMessage(),500]);
        }
        return $model_data;
    }

    public function update($request,$id){

        $data = $request->all();
        try{
            if(array_key_exists('password', $data) && !empty($data['password'])){
                $data['password'] = Hash::make($request->password);
            }
            $model_data = $this->model::findOrFail($id);
            if(array_key_exists('image', $data)){
                if(empty($data['image'])){
                    unset($data['image']);
                }
                else{
                    $image_path = 'public/'.str_replace('storage/','',$model_data->image);
                    Storage::delete($image_path); 
                }
            }
            $model_data->update($data);

            if(array_key_exists('role', $data)){
                $model_data->roles()->detach();
                $model_data->roles()->attach($data['role']);
            }
        }
        catch(\Exception $exception){
            return response()->json(['error'=>$exception->getMessage()],500);
        }
        return['message'=>'Successfull'];
    }

    public function destroy($id){

        try{
            $model_data = $this->model::findOrFail($id);
            if($model_data->image){
                $image = explode('/',$model_data->image);
                if(count($image) > 4){
                    Storage::deleteDirectory('public/uploads/'.$image[4]);
                }
                else{
                    Storage::deleteDirectory('public/uploads/'.$image[2]); 
                }
            }
            $model_data->delete();
        }
        catch(\Exception $exception){
            return response()->json(['error'=>$exception->getMessage()],500);
        }
        return['message'=>'Successfull'];
    }

    public function date_search($request){
        
        try{
            if($request->startDate != '' && $request->endDate != ''){
                return $this->model::whereDate('created_at','>=',$request->startDate)
                            ->whereDate('created_at','<=',$request->endDate)
                            ->paginate(10);
            }
            elseif($request->startDate != '' && $request->endDate == ''){
                return $this->model::whereDate('created_at','>=',$request->startDate)
                            ->paginate(10);
            }
            elseif($request->startDate == '' && $request->endDate != ''){
                return $this->model::whereDate('created_at','<=',$request->endDate)
                            ->paginate(10);
            }
            else{
                return $this->model::paginate(10);
            }
        }
        catch(\Exception $exception){
            return response()->json(['error'=>$exception->getMessage()],500);
        }
    }

    public function list($request){
        $table_ids = DB::table('user_wishlisteds')
                            ->where('user_id',auth()->user()->id)
                            ->whereNotNull($this->db.'_id')
                            ->pluck($this->db.'_id');

        $user_wishlist = DB::table($this->db.'s')
                            ->select(DB::raw(' '.$this->db.'s.* , user_wishlisteds.user_id'))
                            ->rightJoin('user_wishlisteds',''.$this->db.'s.id','=','user_wishlisteds.'.$this->db.'_id')
                            ->whereNotNull('user_wishlisteds.'.$this->db.'_id')
                            ->where('user_wishlisteds.user_id',auth()->user()->id);

        return $data = DB::table($this->db.'s')
                            ->select(DB::raw(' '.$this->db.'s.* , "" as is_wishlisted'))
                            ->union($user_wishlist)
                            ->whereNotIn('id',$table_ids)
                            ->orderBy('id','asc')
                            ->paginate(5);
    }

    public function popular($request){
        $hut_ids = DB::table('user_wishlisteds')
                            ->where('user_id',auth()->user()->id)
                            ->pluck($this->db.'_id');

        $user_huts = DB::table($this->db.'s')
                            ->select(DB::raw(' '.$this->db.'s.* , user_wishlisteds.user_id'))
                            ->rightJoin('user_wishlisteds',''.$this->db.'s.id','=','user_wishlisteds.'.$this->db.'_id')
                            ->where('user_wishlisteds.user_id',auth()->user()->id);

        return $huts = DB::table($this->db.'s')
                            ->select(DB::raw(' '.$this->db.'s.* , "" as is_wishlisted'))
                            ->union($user_huts)
                            ->whereNotIn('id',$hut_ids)
                            ->orderBy('rating','desc')
                            ->paginate(5);
    }

    public function featured($request){
        return DB::table($this->db.'s')
        ->where('featured_duration','>',now())
        ->orderBy('rating','desc')
        ->paginate(5);
    }

    public function storeImage($request){
        $image_type = str_replace('data:image/','',$request['image_type']);
        $image_type = str_replace(';base64','',$image_type);
        $file_name = now()->timestamp;
        Storage::disk('public')->put($file_name.'.'.$image_type,base64_decode($request['image']));
        return 'storage/'.$file_name.'.'.$image_type;
    }
}