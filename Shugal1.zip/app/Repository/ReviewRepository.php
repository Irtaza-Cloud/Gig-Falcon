<?php

namespace App\Repository;

use App\Review;
use App\Hut;
use Hash;
use DB;
use App\Repository\RepositoryCRUD;

class ReviewRepository extends RepositoryCRUD
{
    public function __construct()
    {
        $this->model = 'App\Review';
    }

    public function like_review($request){
        return Review::find($request->review_id)->update([
            'like'=>$request->like,
        ]);
    }

    public function review_reply($request){
        return Review::create($request->all());
    }

    public function vendor_reviews(){
        $review_count = Review::where('receiver_id',auth()->user()->id)->count();
        $review = Review::where('receiver_id',auth()->user()->id)->get();
        return [
            'review_count' => $review_count,
            'review' => $review,
        ];
    }
}