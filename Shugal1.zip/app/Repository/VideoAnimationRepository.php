<?php

namespace App\Repository;

use App\FarmHouse;
use Hash;
use DB;
use App\VideoAnimation;
use App\Repository\RepositoryCRUD;

class VideoAnimationRepository extends RepositoryCRUD
{
    public function __construct()
    {
        $this->model = 'App\FarmHouse';
        $this->db = 'farm_house';
    }

 	public function search($request){
        return VideoAnimation::where('name','like','%'.$request->q.'%')
        ->orWhere('city','like','%'.$request->q.'%')
        ->orWhere('address','like','%'.$request->q.'%')
        ->orWhere('area','like','%'.$request->q.'%')
        ->orWhere('description','like','%'.$request->q.'%')
        ->orWhere('no_of_rooms','like','%'.$request->q.'%')
        ->orWhere('no_of_floors','like','%'.$request->q.'%')
        ->orWhere('slots','like','%'.$request->q.'%')
        ->orWhere('rent_per_day','like','%'.$request->q.'%')
        ->orWhere('rent_per_slot','like','%'.$request->q.'%')
        ->orWhere('rating','like','%'.$request->q.'%')
        ->orWhere('facilities','like','%'.$request->q.'%')
        ->paginate(10);
    }

    public function popular_farmhouses($request){
        return VideoAnimation::orderBy('rating','desc')->paginate(10);
    }

    public function get_farmhouses($id){
        try{
            $model_data = $this->model::withCount('check_in')->find($id);
            $rating = Rating::select('rating as user_rating')
                        ->where($this->db.'_id',$id)
                        ->where('user_id',auth()->user()->id)
                        ->first();

            $model_data['user_rating'] = $rating;

        }
        catch(\Exception $exception){
            return response()->json(['error'=>$exception->getMessage()]);
        }
        return $model_data;
    }
}
