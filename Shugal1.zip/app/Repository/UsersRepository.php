<?php

namespace App\Repository;

use App\User;
use App\GraphicDesign;
use App\DigitalMarketing;
use App\FunLifestyle;
use App\MusicsAudio;
use Illuminate\Support\Facades\DB;
use App\ProgrammingTech;
use App\Business;
use App\VideoAnimation;
use App\WritingTranslation;
use App\UserWishlisted;
use App\Booking;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use App\Repository\RepositoryCRUD;
use Carbon\Carbon;

class UsersRepository extends RepositoryCRUD
{
    public function __construct()
    {
        $this->model = 'App\User';
    }

 	public function search($request){
        return User::where('name','like','%'.$request->q.'%')
                    ->orWhere('email','like','%'.$request->q.'%')
                    ->paginate(10);
    }

    public function get_number(){
        $graphic_designings = GraphicDesign::all()->count();
        $programming_tech = ProgrammingTech::all()->count();
        $businesses = Business::all()->count();
        $video_animations = VideoAnimation::all()->count();
        $digital_marketings = DigitalMarketing::all()->count();
        $writing_translations = WritingTranslation::all()->count();
        $fun_lifestyles = FunLifestyle::all()->count();
        $music_audios = MusicsAudio::all()->count();
        return [
            'graphic_designings'=>$graphic_designings,
            'programming_tech'=>$programming_tech,
            'businesses'=>$businesses,
            'video_animations'=>$video_animations,
            'digital_marketings'=>$digital_marketings,
            'writing_translations'=>$writing_translations,
            'fun_lifestyles'=>$fun_lifestyles,
            'music_audios'=>$music_audios,
        ];
    }

    public function wishlist($request){
        $data = $request->all();
        $data['user_id'] = auth()->user()->id;
        $check = UserWishlisted::where('user_id',auth()->user()->id)
                    ->where(array_keys($data)[0],array_values($data)[0])
                    ->count();

        if(empty($check)){
            UserWishlisted::create($data);
            return response()->json(['msg'=>'added to wishlist']);
        }
        else{
            UserWishlisted::where('user_id',auth()->user()->id)
                    ->where(array_keys($data)[0],array_values($data)[0])
                    ->delete();
            return response()->json(['msg'=>'remove from wishlist']);
        }
    }

    public function vendor_dashboard(){
        $pending_bookings = Booking::where('vendor_id',auth()->user()->id)
                            ->where('status','pending')
                            ->whereDate('booking_date','>=',today())
                            ->count();

        $earning_from_all = DB::table('transactions')
        ->select('amount')
        ->where('transactions.vendor_id', auth()->user()->id)
        ->sum('amount');

        $your_rating = User::select('rating')->find(auth()->user()->id);

        $bookings_today = Booking::where('vendor_id',auth()->user()->id)
                            ->whereDate('booking_date','<=',today())
                            ->whereDate('booking_date','>=',today())
                            ->count();

        $upcoming_bookings = Booking::where('vendor_id',auth()->user()->id)
                            ->whereDate('booking_date','>=',today())
                            ->count();

        $earning_this_week =  DB::table('transactions')
        ->select('amount')
        ->where('transactions.created_at', '>', Carbon::now()->startOfWeek())
        ->where('transactions.created_at', '<', Carbon::now()->endOfWeek())
        ->where('transactions.vendor_id', auth()->user()->id)
        ->sum('amount');

        $earning_this_month = DB::table('transactions')
        ->select('amount')
        ->where('transactions.created_at', '>', Carbon::now()->startOfMonth())
        ->where('transactions.created_at', '<', Carbon::now()->endOfMonth())
        ->where('transactions.vendor_id', auth()->user()->id)
        ->sum('amount');

        return [
            'pending_bookings'=>$pending_bookings,
            'earning_from_all'=>$earning_from_all,
            'your_rating'=>$your_rating,
            'bookings_today'=>$bookings_today,
            'upcoming_bookings'=>$upcoming_bookings,
            'earning_this_week'=>$earning_this_week,
            'earning_this_month'=>$earning_this_month,
        ];
    }

    public function my_assets(){
        $graphic_designings = GraphicDesign::where('vendor_id',auth()->user()->id)->get();
        $programming_tech = ProgrammingTech::where('vendor_id',auth()->user()->id)->get();
        $businesses = Business::where('vendor_id',auth()->user()->id)->get();
        $video_animations = VideoAnimation::where('vendor_id',auth()->user()->id)->get();
        $digital_marketings = DigitalMarketing::where('vendor_id',auth()->user()->id)->get();
        $writing_translations = WritingTranslation::where('vendor_id',auth()->user()->id)->get();
        $fun_lifestyles = FunLifestyle::where('vendor_id',auth()->user()->id)->get();
        $music_audios = MusicsAudio::where('vendor_id',auth()->user()->id)->get();

        return [
            'graphic_designings'=>$graphic_designings,
            'programming_tech'=>$programming_tech,
            'businesses'=>$businesses,
            'video_animations'=>$video_animations,
            'digital_marketings'=>$digital_marketings,
            'writing_translations'=>$writing_translations,
            'fun_lifestyles'=>$fun_lifestyles,
            'music_audios'=>$music_audios,
        ];
    }
}
