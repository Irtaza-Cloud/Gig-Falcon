<?php

namespace App\Repository;

use App\CheckInOut;
use App\Hut;
use Hash;
use DB;
use App\Repository\RepositoryCRUD;

class CheckInOutRepository extends RepositoryCRUD
{
    public function __construct()
    {
        $this->model = 'App\CheckInOut';
    }

 	public function search($request){
        return CheckInOut::whereHas('user',function($query)use($request){
                            $query->where('name','like','%'.$request->q.'%');
                        })->orWhereHas('hut',function($query)use($request){
                            $query->where('name','like','%'.$request->q.'%');
                        })->orWhere('check_in_time','like','%'.$request->q.'%')
                        ->orWhere('check_out_time','like','%'.$request->q.'%')
                        ->paginate(10);
    }

    public function checkinout_date_search($request){
        try{
            if($request->startDate != '' && $request->endDate != ''){
                return $this->model::whereDate('check_in_time','>=',$request->startDate)
                            ->whereDate('check_in_time','<=',$request->endDate)
                            ->paginate(10);
            }
            elseif($request->startDate != '' && $request->endDate == ''){
                return $this->model::whereDate('check_in_time','>=',$request->startDate)
                            ->paginate(10);
            }
            elseif($request->startDate == '' && $request->endDate != ''){
                return $this->model::whereDate('check_in_time','<=',$request->endDate)
                            ->paginate(10);
            }
            else{
                return $this->model::paginate(10);
            }
        }
        catch(\Exception $exception){
            return response()->json(['error'=>$exception->getMessage()],500);
        }
    }
}