<?php

namespace App\Repository;

use App\Transaction;
use App\Hut;
use Hash;
use DB;
use App\Repository\RepositoryCRUD;
use Carbon\Carbon;

class TransactionRepository extends RepositoryCRUD
{
    public function __construct()
    {
        $this->model = 'App\Transaction';
    }

    public function week_earnings(){
        $booking_data = DB::table('bookings')
        ->select(
            DB::raw('count(*) as booking_count'), 
            DB::raw("DATE_FORMAT(created_at,'%D %M %Y') as date")
        )
        ->where('bookings.created_at', '>', Carbon::now()->startOfWeek())
        ->where('bookings.created_at', '<', Carbon::now()->endOfWeek())
        ->where('bookings.vendor_id', auth()->user()->id)
        ->groupBy('date')
        ->get();

        $earning_data = DB::table('transactions')
        ->select(
            DB::raw('sum(amount) as sums'), 
            DB::raw("DATE_FORMAT(created_at,'%D %M %Y') as date")
        )
        ->where('transactions.created_at', '>', Carbon::now()->startOfWeek())
        ->where('transactions.created_at', '<', Carbon::now()->endOfWeek())
        ->where('transactions.vendor_id', auth()->user()->id)
        ->groupBy('date')
        ->get();

        $total_earnings = DB::table('transactions')
        ->select('amount')
        ->where('transactions.created_at', '>', Carbon::now()->startOfWeek())
        ->where('transactions.created_at', '<', Carbon::now()->endOfWeek())
        ->where('transactions.vendor_id', auth()->user()->id)
        ->sum('amount');

        return [
            'total_earnings'=>$total_earnings,
            'earning_data'=>$earning_data,
            'booking_data'=>$booking_data,
        ];
    }

    public function month_earnings(){
        $booking_data = DB::table('bookings')
        ->select(
            DB::raw('count(*) as booking_count'), 
            DB::raw("DATE_FORMAT(created_at,'%D %M %Y') as date")
        )
        ->where('bookings.created_at', '>', Carbon::now()->startOfMonth())
        ->where('bookings.created_at', '<', Carbon::now()->endOfMonth())
        ->where('bookings.vendor_id', auth()->user()->id)
        ->groupBy('date')
        ->get();

        $earning_data = DB::table('transactions')
        ->select(
            DB::raw('sum(amount) as sums'), 
            DB::raw("DATE_FORMAT(created_at,'%D %M %Y') as date")
        )
        ->where('transactions.created_at', '>', Carbon::now()->startOfMonth())
        ->where('transactions.created_at', '<', Carbon::now()->endOfMonth())
        ->where('transactions.vendor_id', auth()->user()->id)
        ->groupBy('date')
        ->get();

        $total_earnings = DB::table('transactions')
        ->select('amount')
        ->where('transactions.created_at', '>', Carbon::now()->startOfMonth())
        ->where('transactions.created_at', '<', Carbon::now()->endOfMonth())
        ->where('transactions.vendor_id', auth()->user()->id)
        ->sum('amount');

        return [
            'total_earnings'=>$total_earnings,
            'earning_data'=>$earning_data,
            'booking_data'=>$booking_data,
        ];
    }

    public function add_to_featured($request){
        $request['user_id'] = auth()->user()->id;
        $table = '';
        if($request->hut_id){
            $vendor = Hut::find($request->hut_id);
            $table = 'huts';
        }
        if($request->catering_id){
            $vendor = Catering::find($request->catering_id);
            $table = 'caterings';
        }
        if($request->decorator_id){
            $vendor = Decorator::find($request->decorator_id);
            $table = 'decorators';
        }
        if($request->farmhouse_id){
            $vendor = FarmHouse::find($request->farmhouse_id);
            $table = 'farm_houses';
        }
        if($request->hotelrestaurant_id){
            $vendor = HotelRestaurant::find($request->hotelrestaurant_id);
            $table = 'hotel_restaurant';
        }
        if($request->lawnbanquet_id){
            $vendor = LawnBanquet::find($request->lawnbanquet_id);
            $table = 'lawn_banquets';
        }
        if($request->photographer_id){
            $vendor = Photographer::find($request->photographer_id);
            $table = 'photographers';
        }
        if($request->transport_id){
            $vendor = Transport::find($request->transport_id);
            $table = 'transporters';
        }
        if(empty($vendor)){
            return response()->json(['error'=>'invalid venue id']);
        }
        DB::table($table)
        ->where('id',$vendor->id)
        ->update([
            'featured_duration'=>Carbon::now()->addDays($request->no_of_days),
        ]);
        Transaction::create($request->all());
    }
}