<?php

namespace App\Repository;

use App\DigitalMarketing;
use Hash;
use DB;
use App\Repository\RepositoryCRUD;

class DigitalMarketingingRepository extends RepositoryCRUD
{
    public function __construct()
    {
        $this->model = 'App\Catering';
        $this->db = 'catering';
    }

 	public function search($request){
        return DigitalMarketing::where('name','like','%'.$request->q.'%')
        ->orWhere('address','like','%'.$request->q.'%')
        ->orWhere('description','like','%'.$request->q.'%')
        ->orWhere('service_hours','like','%'.$request->q.'%')
        ->orWhere('seating_capacity','like','%'.$request->q.'%')
        ->orWhere('specialities','like','%'.$request->q.'%')
        ->orWhere('minimum_servings','like','%'.$request->q.'%')
        ->orWhere('charge_per_person','like','%'.$request->q.'%')
        ->orWhere('rent_per_day','like','%'.$request->q.'%')
        ->orWhere('rating','like','%'.$request->q.'%')
        ->orWhere('contact','like','%'.$request->q.'%')
        ->paginate(10);
    }

    public function popular_caterings($request){
        return DigitalMarketing::orderBy('rating','desc')->paginate(10);
    }

    public function get_wish_listed($DigitalMarketing){
        $wishlist = json_decode(auth()->user()->wishlisted_digital_marketings_id);
        for ($i=0; $i < count($DigitalMarketing); $i++) {
            if(!empty($DigitalMarketing)){
                for ($j=0; $j < count($wishlist); $j++) {
                    if($DigitalMarketing[$i]['id'] == $DigitalMarketing[$j]){
                        $DigitalMarketing[$i]['iswishlisted'] = true;
                        continue 2;
                    }
                    else{
                        $DigitalMarketing[$i]['iswishlisted'] = false;
                    }
                }
            }
            else{
                $DigitalMarketing[$i]['iswishlisted'] = false;
            }
        }
        return $DigitalMarketing;
    }

    public function get_caterings($id){
        try{
            $model_data = $this->model::find($id);
            $rating = Rating::select('rating as user_rating')
                        ->where($this->db.'_id',$id)
                        ->where('user_id',auth()->user()->id)
                        ->first();

            $model_data['user_rating'] = $rating;

        }
        catch(\Exception $exception){
            return response()->json(['error'=>$exception->getMessage()]);
        }
        return $model_data;
    }
}
