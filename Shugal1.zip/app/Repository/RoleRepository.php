<?php

namespace App\Repository;

use App\Role;
use Illuminate\Support\Facades\Storage;
use Hash;
use DB;
use App\Repository\RepositoryCRUD;

class RoleRepository extends RepositoryCRUD
{
    public function __construct()
    {
        $this->model = 'App\Role';
    }

    public function storeRole($request){
        $data = $request->all();
        $permissions = '{';
        for($i=0; $i<count($data['permissions']); $i++){
            foreach ($data['permissions'][$i] as $key) {
                if($key == 'true'){
                    $permissions .= ':'.$key.',';
                }
                else{
                    $permissions .='"'.$key.'"';
                }
            }
        }
        $permissions = substr($permissions,0, strlen($permissions)-1)."}";
        return Role::create([
            'name'=>$data['name'],
            'permissions'=>$permissions,
        ]);
    }

    public function updateRole($request,$id){
        $data = $request->all();
        $permissions = '{';
        for($i=0; $i<count($data['permissions']); $i++){
            foreach ($data['permissions'][$i] as $key) {
                if($key == 'true'){
                    $permissions .= ':'.$key.',';
                }
                else{
                    $permissions .='"'.$key.'"';
                }
            }
        }
        $permissions = substr($permissions,0, strlen($permissions)-1)."}";
        return Role::findOrfail($id)->update([
            'name'=>$data['name'],
            'permissions'=>$permissions,
        ]);
    }

    public function search($request){
        return User::where('name','like','%'.$request->q.'%')
                    ->orWhere('email','like','%'.$request->q.'%')
                    ->orWhere('type','like','%'.$request->q.'%')
                    ->paginate(10);
    }

}
