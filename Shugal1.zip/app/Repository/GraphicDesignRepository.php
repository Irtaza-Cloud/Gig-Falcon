<?php

namespace App\Repository;

use App\GraphicDesign;
use App\Hut;
use App\Rating;
use Hash;
use DB;
use App\Repository\RepositoryCRUD;

class GraphicDesignRepository extends RepositoryCRUD
{
    public function __construct()
    {
        $this->model = 'App\Hut';
        $this->db = 'hut';
    }

 	public function search($request){
        return GraphicDesign::where('name','like','%'.$request->q.'%')
        ->orWhere('city','like','%'.$request->q.'%')
        ->orWhere('address','like','%'.$request->q.'%')
        ->orWhere('area','like','%'.$request->q.'%')
        ->orWhere('description','like','%'.$request->q.'%')
        ->orWhere('no_of_rooms','like','%'.$request->q.'%')
        ->orWhere('no_of_floors','like','%'.$request->q.'%')
        ->orWhere('slots','like','%'.$request->q.'%')
        ->orWhere('rent_per_day','like','%'.$request->q.'%')
        ->orWhere('rent_per_slot','like','%'.$request->q.'%')
        ->orWhere('rating','like','%'.$request->q.'%')
        ->orWhere('facilities','like','%'.$request->q.'%')
        ->paginate(10);
    }

    public function get_huts($id){
        try{
            $model_data = $this->model::withCount('check_in')->find($id);
            $rating = Rating::select('rating as user_rating')
                        ->where($this->db.'_id',$id)
                        ->where('user_id',auth()->user()->id)
                        ->first();

            $model_data['user_rating'] = $rating;

        }
        catch(\Exception $exception){
            return response()->json(['error'=>$exception->getMessage()]);
        }
        return $model_data;
    }
}
