<?php

namespace App\Repository;

use App\Rating;
use App\Hut;
use Hash;
use DB;
use App\Repository\RepositoryCRUD;

class RatingRepository extends RepositoryCRUD
{
    public function __construct()
    {
        $this->model = 'App\Rating';
    }

 	public function search($request){
        return Rating::whereHas('user',function($query)use($request){
                            $query->where('name','like','%'.$request->q.'%');
                        })->orWhereHas('hut',function($query)use($request){
                            $query->where('name','like','%'.$request->q.'%');
                        })->orWhere('rating','like','%'.$request->q.'%')
                        ->paginate(10);
    }

    public function update_table_rating($request){
        $data = $request->all();
        $rating = DB::table('ratings')
                ->select(DB::raw('count(*) as count, sum(rating) as rating'))
                ->where(array_keys($data)[0], array_values($data)[0])
                ->get();

        DB::table(str_replace('_id','',array_keys($data)[0]).'s')
            ->where('id',array_values($data)[0])
            ->update([
                'rating'=>$rating[0]->rating/$rating[0]->count,
            ]);

        return true;
    }
}