<?php

namespace App\Repository;

use App\FunLifestyle;
use Hash;
use DB;
use App\Repository\RepositoryCRUD;

class FunandLifestyleRepository extends RepositoryCRUD
{
    public function __construct()
    {
        $this->model = 'App\Photographer';
        $this->db = 'photographer';
    }

 	public function search($request){
        return FunLifestyle::where('name','like','%'.$request->q.'%')
        ->orWhere('address','like','%'.$request->q.'%')
        ->orWhere('description','like','%'.$request->q.'%')
        ->orWhere('service_hours','like','%'.$request->q.'%')
        ->orWhere('equipments','like','%'.$request->q.'%')
        ->orWhere('specialities','like','%'.$request->q.'%')
        ->orWhere('slots','like','%'.$request->q.'%')
        ->orWhere('rent_per_slot','like','%'.$request->q.'%')
        ->orWhere('rating','like','%'.$request->q.'%')
        ->orWhere('contact','like','%'.$request->q.'%')
        ->paginate(10);
    }

    public function popular_photographers($request){
        return FunLifestyle::orderBy('rating','desc')->paginate(10);
    }

    public function get_photographers($id){
        try{
            $model_data = $this->model::find($id);
            $rating = Rating::select('rating as user_rating')
                        ->where($this->db.'_id',$id)
                        ->where('user_id',auth()->user()->id)
                        ->first();

            $model_data['user_rating'] = $rating;

        }
        catch(\Exception $exception){
            return response()->json(['error'=>$exception->getMessage()]);
        }
        return $model_data;
    }
}
