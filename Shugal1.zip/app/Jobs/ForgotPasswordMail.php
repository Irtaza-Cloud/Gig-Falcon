<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use App\Mail\ForgotPassword;
use Illuminate\Support\Facades\Mail;

class ForgotPasswordMail implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $verification_code;
    public $email;

    public function __construct($email,$verification_code)
    {
        $this->email = $email;
        $this->verification_code = $verification_code;
    }

    public function handle()
    {
        Mail::to($this->email)->send(new ForgotPassword($this->verification_code));
    }
}
