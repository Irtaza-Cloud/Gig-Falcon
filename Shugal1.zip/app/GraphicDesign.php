<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GraphicDesign extends Model
{
    // protected $with = ['user_rating'];

    protected $fillable = [
        'name','image','address','city','description','service_hours','area','no_of_floors','no_of_rooms','slots','rent_per_slot','rent_per_day','facilities','rating','contact','vendor_id','featured_duration'
    ];

    // public function check_in(){
    //     return $this->hasMany('App\CheckInOut');
    // }

    public function user_rating(){
        return $this->hasMany('App\Rating');
    }
}
