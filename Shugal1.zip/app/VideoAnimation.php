<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VideoAnimation extends Model
{
    protected $fillable = [
        'name','image','address','city','description','service_hours','area','no_of_floors','no_of_rooms','slots','rent_per_slot','rent_per_day','facilities','rating','contact','vendor_id','featured_duration'
    ];
}
