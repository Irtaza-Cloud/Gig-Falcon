<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MusicsAudio extends Model
{
    protected $fillable = [
        'name','image','vehicle_name','vehicle_model','description','service_hours','seating_capacity','facilities','slots','rent_per_slot','rent_per_day','rating','contact','vendor_id','featured_duration'
    ];
}
