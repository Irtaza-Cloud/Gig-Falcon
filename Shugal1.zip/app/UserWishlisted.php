<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserWishlisted extends Model
{
    protected $fillable = [
        'user_id','hut_id','catering_id','photographer_id','transport_id','hotel_restaurant_id','lawn_banquet_id','farm_house_id','decorator_id'
    ];
}
