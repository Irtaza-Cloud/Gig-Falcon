<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CheckInOut extends Model
{
    protected $with = ['user','hut'];
    
    protected $fillable = [
        'user_id','hut_id','check_in_time','check_out_time'
    ];

    public function user(){
        return $this->belongsTo('App\User');
    }

    public function hut(){
        return $this->belongsTo('App\Hut');
    }
}
