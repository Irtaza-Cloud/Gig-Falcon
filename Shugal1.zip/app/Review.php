<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
    protected $with = ['reply','user','huts','caterings','decorators','photographers','farmhouses','hotelrestaurants','lawnbanquets','transports'];
    
    protected $fillable = [
        'sender_id','receiver_id','hut_id','farm_house_id','catering_id','decorator_id','hotel_restaurant_id','photographer_id','lawn_banquet_id','transport_id','review','like','reply'
    ];

    public function reply(){
        return $this->hasMany('App\Review','reply');
    }

    public function user(){
        return $this->belongsTo('App\User','sender_id');
    }

    public function huts(){
        return $this->belongsTo('App\Hut','hut_id');
    }

    public function caterings(){
        return $this->belongsTo('App\Catering','catering_id');
    }

    public function decorators(){
        return $this->belongsTo('App\Decorator','decorator_id');
    }

    public function photographers(){
        return $this->belongsTo('App\Photographer','photographer_id');
    }

    public function farmhouses(){
        return $this->belongsTo('App\FarmHouse','farm_house_id');
    }

    public function hotelrestaurants(){
        return $this->belongsTo('App\HotelRestaurant','hotel_restaurant_id');
    }

    public function lawnbanquets(){
        return $this->belongsTo('App\LawnBanquet','lawn_banquet_id');
    }

    public function transports(){
        return $this->belongsTo('App\Transport','transport_id');
    }
}
