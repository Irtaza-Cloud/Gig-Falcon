<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProgrammingTech extends Model
{
    protected $fillable = [
        'name','image','address','description','service_hours','seating_capacity','decor_packages','minimum_guests','slots','rent_per_slot','rating','contact','vendor_id','featured_duration'
    ];
}
