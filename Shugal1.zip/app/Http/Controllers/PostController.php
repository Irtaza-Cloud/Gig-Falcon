<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Post;

class PostController extends Controller
{
    //
    public function store(Request $req)
    {
$this->validate($req, [
    'body' => 'required'
]);
DB::table('posts')->insert([
    'user_id' => auth()->user()->id,
    'post' => $req->body,
    'created_at' => \Carbon\Carbon::now(),
    'updated_at' => \Carbon\Carbon::now(),
]);
return "Post Uploaded";
return back();
    }


    public  function signup(Request $req)
    {

        $this->validate($req, [
            'body' => 'required'
        ]);

        $posts=new Post;
        $posts->post=$req->input('post');

        $posts->save();
        $posts->attachRole($req->role_id);

        if($posts->save()){
            return redirect('profile');

        }
        else{
            return back()->with('fail', 'Something went wrong, Try again later');
        }




    }




}
