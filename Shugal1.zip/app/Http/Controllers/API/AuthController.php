<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Laravel\Passport\Passport;
use Laravel\Passport\PassportServiceProvider;
use Laravel\Passport\PassportUserProvider;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use App\Jobs\ForgotPasswordMail;
use App\Mail\ForgotPassword;
use Illuminate\Support\Facades\Mail;
use Laravel\Passport\Token;
use Illuminate\Support\Facades\Storage;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

class AuthController extends Controller
{
	public $successStatus = 200;

    public function login(){
        if(Auth::attempt(['email' => request('email'), 'password' => request('password')])){
            $user = Auth::user();
            // if($user->status == 0){
            //     return response()->json(['error'=>'Your account is disabled'], 400);
            // }
            $success['token'] =  $user->createToken('MyApp')->accessToken;
            $success['user'] = $user;
            // if(empty($user->remember_device)){
            if(empty($user->is_verified)){
                $verification_code = $this->send_mail($user->email);
                $success['user']['verification_code'] = $verification_code->original['verification_code'];
            }
            return response()->json($success, $this->successStatus);
            return response()->json(['error'=>'Successfully Logged In']);

        }
        else{
            return response()->json(['error'=>'Invalid Email Or Password']);
        }
    }
/**
     * Register api
     *
     * @return \Illuminate\Http\Response
     */
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'username' => 'required', 'string', 'unique:users',
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => 'required', 'min:8',
            // 'c_password' => 'required|same:password',
        ]);
		if ($validator->fails()) {
            if(array_key_exists('email',$validator->errors()->messages())){
                return response()->json(['error'=>'Your email is already registered please goto Sign in']);
            }
            return response()->json(['error'=>$validator->errors()->first()]);
        }
		$input = $request->all();
        $input['password'] = bcrypt($input['password']);
        if(array_key_exists('image_type',$input)){
            $image_type = str_replace('image/','',$request['image_type']);
            // $image_type = str_replace(';base64','',$image_type);
            $file_name = now()->timestamp;
            Storage::disk('public')->put($file_name.'.'.$image_type,base64_decode($request['image']));
            $input['image'] = 'storage/'.$file_name.'.'.$image_type;
        }
        else{
            $input['image'] = 'img/person.png';
        }
        $input['contact'] = 'N/A';
        $input['address'] = 'N/A';
        $user = User::create($input);
        if(array_key_exists('vendor',$input)){
            $user->roles()->attach(3);
        }
        else{
            $user->roles()->attach(2);
        }
        $success['token'] =  $user->createToken('MyApp')->accessToken;
        $verification_code = $this->send_mail($user->email);
        $success['user'] = $user;
        $success['user']['verification_code'] = $verification_code->original['verification_code'];
		return response()->json($success, $this->successStatus);
        return("new user registered");
    }

    public function forgot_password(Request $request){
        return $this->send_mail($request->email);
    }

    public function send_mail($email){
        $six_digit_random_number = mt_rand(100000, 999999);
        // $job = (new ForgotPasswordMail($email,$six_digit_random_number))->delay(Carbon::now()->addSeconds(1));
        // dispatch($job);
        // Mail::to($email)->send(new ForgotPassword($six_digit_random_number));
        User::where('email',$email)->update([
            'verification_code'=>$six_digit_random_number,
        ]);
        return response()->json(['verification_code'=>$six_digit_random_number]);
    }

    public function remember_device(Request $request){
        User::find($request->user_id)->update([
            'remember_device'=>'ncjasnvjas',
        ]);
        return response()->json(['message'=>'success']);
    }

    public function validate_token(){
        $user = auth()->user();
        return response()->json(['users'=>$user]);
    }

    public function invalid_token(){
        return response()->json(['error'=>'Invalid Token'], 404);
    }

    public function otp_verified(){
        User::find(auth()->user()->id)->update([
            'is_verified'=>1,
        ]);

        return response()->json(['message'=>'success']);
    }

    public function change_password(Request $request){
        $user = User::find(auth()->user()->id);
        if(Hash::check($request->old_password, $user->password)){
            $user->update([
                'password'=>bcrypt($request->new_password),
            ]);
            return response()->json(['message'=>'Password Successfully Changed!']);
        }
        return response()->json(['error'=>'Incorrect Password']);
    }

    public function update_profile(Request $request){
        try{
            $data = $request->all();
            if(!str_contains($data['image'], 'storage')){
                $image_type = explode('/',$data['type']);
                $file_name = Carbon::now()->timestamp;
                Storage::disk('public')->put($file_name.'.'.$image_type[1],base64_decode($data['image']));
                $data['image'] = 'storage/'.$file_name.'.'.$image_type[1];
            }
            // else{
            //     $image_url = explode('storage',$data['image']);
            //     $data['image'] = 'storage'.$image_url[1];
            // }
            User::find(auth()->user()->id)->update($data);
            $data = [
                'token'=>$request->bearerToken(),
                'users'=>User::find(auth()->user()->id),
            ];
            return response()->json($data);
        }
        catch(\Exception $exception){
            return response()->json(['error'=>$exception->getMessage()]);
        }
        return response()->json(['message'=>'success']);
    }

}
