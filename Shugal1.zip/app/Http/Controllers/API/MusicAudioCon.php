<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repository\MusicandAudioRepository;
use App\Http\Requests\MusicandAudioValidation;
use Illuminate\Support\Facades\Gate;

class MusicAudioCon extends Controller
{
    private $MusicandAudioRepository;

    public function __construct(MusicandAudioRepository $MusicandAudioRepository)
    {
        $this->middleware('auth:api');
        $this->MusicandAudioRepository = $MusicandAudioRepository;
    }

    public function list(Request $request){
        return $this->MusicandAudioRepository->list($request);
    }

    public function popular(Request $request)
    {
        return $this->MusicandAudioRepository->popular($request);
    }

    public function featured(Request $request)
    {
        return $this->MusicandAudioRepository->featured($request);
    }

    public function index(Request $request)
    {
        if(Gate::allows('view-music_audios')){
            $MusicandAudio = $this->MusicandAudioRepository->index($request);
            return $MusicandAudio;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function store(MusicandAudioValidation $request)
    {
        if(Gate::allows('create-music_audios')){
            $validated = $request->validated();
            if($request->image_type){
                $request['image'] = $this->MusicandAudioRepository->storeImage($request);
            }
            if(!$request->vendor_id){
                $request['vendor_id'] = auth()->user()->id;
            }
            if(is_array($request['facilities'])){
                $request['facilities'] = implode(',',$request['facilities']);
            }
            $MusicandAudio = $this->MusicandAudioRepository->store($request);
            return $MusicandAudio;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function show($id)
    {
        $MusicandAudio = $this->MusicandAudioRepository->get_music_audios($id);
        return response()->json($MusicandAudio);
    }

    public function update(MusicandAudioValidation $request, $id)
    {
        if(Gate::allows('update-music_audios')){
            $validated = $request->validated();
            $MusicandAudio = $this->MusicandAudioRepository->update($request,$id);
            return $MusicandAudio;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function destroy($id)
    {
        if(Gate::allows('delete-music_audios')){
            $MusicandAudio = $this->MusicandAudioRepository->destroy($id);
            return $MusicandAudio;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function search(Request $request)
    {
        $MusicandAudio = $this->MusicandAudioRepository->search($request);
        return $MusicandAudio;
    }

    public function date_search(Request $request)
    {
        $MusicandAudio = $this->MusicandAudioRepository->date_search($request);
        return $MusicandAudio;
    }
}
