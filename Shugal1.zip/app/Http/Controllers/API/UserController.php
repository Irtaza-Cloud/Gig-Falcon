<?php

namespace App\Http\Controllers\API;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repository\UsersRepository;
use App\Http\Requests\StoreUserValidation;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\UpdateUserValidation;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;

class UserController extends Controller
{
    private $userRepository;

    public function __construct(UsersRepository $userRepository)
    {
        $this->middleware('auth:api');
        $this->userRepository = $userRepository;
    }

    public function index(Request $request)
    {
        if(Gate::allows('view-user')){
            $users = $this->userRepository->index($request);
            return $users;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function store(StoreUserValidation $request)
    {
        if(Gate::allows('create-user')){
            $validated = $request->validated();
            $users = $this->userRepository->store($request);
            return $users;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function show($id)
    {
        $user = $this->userRepository->find($id);
        return response()->json($user);
    }



    public function update(Request $request)
    {
        $user= User::find(Auth::user()->id);

        if($user){
            $validated=null;
if(Auth::user()->email=== $request['email']){
            $validated = $request->validated([
                'username' => 'required', 'string', 'unique:users',
                'email' => ['required', 'string', 'email', 'max:255'],
                'password' => 'required', 'min:8',
            ]);
        }
        else{
            $validated = $request->validated([
                'username' => 'required', 'string', 'unique:users',
                'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
                'password' => 'required', 'min:8',
            ]);

        }
        if($validated){
            $user->username = $request['username'];
            $user->username = $request['email'];
            $user->username = $request['password'];
            $user->save();
            $request->session()->flash('success', 'User Updated Successfully');
            return redirect()->back();
        }

        else{
            return redirect()->back();
            return "Error";
        }
    }
    }

/*
        $users = $this->userRepository->update($request,$id);
        return $users;
    }
    return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
}

*/

    public function destroy($id)
    {
        if(Gate::allows('delete-user')){
            $users = $this->userRepository->destroy($id);
            return $users;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function search(Request $request)
    {
        $users = $this->userRepository->search($request);
        return $users;
    }

    public function date_search(Request $request)
    {
        $users = $this->userRepository->date_search($request);
        return $users;
    }

    public function get_coach_data(){
        $users = $this->userRepository->get_coach_data();
        return response()->json($users);
    }

    public function get_user_diets(){
        $users = $this->userRepository->get_user_diets();
        return response()->json($users);
    }

    public function user_stats(){
        $users = $this->userRepository->user_stats();
        return response()->json($users);
    }

    public function chart_data()
    {
        $users = $this->userRepository->chart_data();
        return response()->json($users);
    }

    public function get_user_name(Request $request)
    {
        return $request->user('api');
    }

    public function get_number()
    {
        $users = $this->userRepository->get_number();
        return $users;
    }

    public function wishlist(Request $request){
        $users = $this->userRepository->wishlist($request);
        return $users;
    }

    public function vendor_dashboard(){
        return $this->userRepository->vendor_dashboard();
    }

    public function my_assets(){
        return $this->userRepository->my_assets();
    }
}
