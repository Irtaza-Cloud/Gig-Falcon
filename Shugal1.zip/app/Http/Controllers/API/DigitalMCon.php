<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repository\DigitalMarketingingRepository;
use App\Http\Requests\DigitalMarketingValidation;
use Illuminate\Support\Facades\Gate;

class DigitalMCon extends Controller
{
    private $CateringRepository;

    public function __construct(DigitalMarketingingRepository $DigitalMarketingingRepository)
    {
        $this->middleware('auth:api');
        $this->DigitalMarketingingRepository = $DigitalMarketingingRepository;
    }

    public function list(Request $request){
        return $this->DigitalMarketingingRepository->list($request);
    }

    public function popular(Request $request)
    {
        return $this->DigitalMarketingingRepository->popular($request);
    }

    public function featured(Request $request)
    {
        return $this->DigitalMarketingingRepository->featured($request);
    }

    public function index(Request $request)
    {
        if(Gate::allows('view-digital_marketings')){
            $DigitalMarketing = $this->DigitalMarketingingRepository->index($request);
            return $DigitalMarketing;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function store(DigitalMarketingValidation $request)
    {
        if(Gate::allows('create-digital_marketings')){
            $validated = $request->validated();
            if($request->image_type){
                $request['image'] = $this->DigitalMarketingingRepository->storeImage($request);
            }
            if(!$request->vendor_id){
                $request['vendor_id'] = auth()->user()->id;
            }
            if(is_array($request['specialities'])){
                $request['specialities'] = implode(',',$request['specialities']);
            }
            $DigitalMarketing = $this->DigitalMarketingingRepository->store($request);
            return $DigitalMarketing;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function show($id)
    {
        $DigitalMarketing = $this->DigitalMarketingingRepository->get_digital_marketings($id);
        return response()->json($DigitalMarketing);
    }

    public function update(DigitalMarketingValidation $request, $id)
    {
        if(Gate::allows('update-digital_marketings')){
            $validated = $request->validated();
            $DigitalMarketing = $this->DigitalMarketingingRepository->update($request,$id);
            return $DigitalMarketing;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function destroy($id)
    {
        if(Gate::allows('delete-digital_marketings')){
            $DigitalMarketing = $this->DigitalMarketingingRepository->destroy($id);
            return $DigitalMarketing;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function search(Request $request)
    {
        $DigitalMarketing = $this->DigitalMarketingingRepository->search($request);
        return $DigitalMarketing;
    }

    public function date_search(Request $request)
    {
        $DigitalMarketing = $this->DigitalMarketingingRepository->date_search($request);
        return $DigitalMarketing;
    }
}
