<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repository\CheckInOutRepository;
use App\Http\Requests\CheckInOutValidation;
use Illuminate\Support\Facades\Gate;

class CheckInOutController extends Controller
{
    private $CheckInOutRepository;

    public function __construct(CheckInOutRepository $CheckInOutRepository)
    {
        $this->middleware('auth:api');
        $this->CheckInOutRepository = $CheckInOutRepository;
    }

    public function index(Request $request)
    {
        if(Gate::allows('view-checkinout')){
            $CheckInOuts = $this->CheckInOutRepository->index($request);
            return $CheckInOuts;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function store(CheckInOutValidation $request)
    {
        if(Gate::allows('create-checkinout')){
            $validated = $request->validated();
            $CheckInOuts = $this->CheckInOutRepository->store($request);
            return $CheckInOuts;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function show($id)
    {
        $CheckInOut = $this->CheckInOutRepository->find($id);
        return response()->json($CheckInOut);
    }

    public function update(CheckInOutValidation $request, $id)
    {
        if(Gate::allows('update-checkinout')){
            $validated = $request->validated();
            $CheckInOuts = $this->CheckInOutRepository->update($request,$id);
            return $CheckInOuts;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function destroy($id)
    {
        if(Gate::allows('delete-checkinout')){
            $CheckInOuts = $this->CheckInOutRepository->destroy($id);
            return $CheckInOuts;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function search(Request $request)
    {
        $CheckInOuts = $this->CheckInOutRepository->search($request);
        return $CheckInOuts;
    }

    public function date_search(Request $request)
    {
        $CheckInOuts = $this->CheckInOutRepository->checkinout_date_search($request);
        return $CheckInOuts;
    }

}
