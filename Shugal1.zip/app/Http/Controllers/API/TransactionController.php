<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repository\TransactionRepository;
use App\Http\Requests\TransactionValidation;
use Illuminate\Support\Facades\Gate;
use Carbon\Carbon;
use App\Hut;
use App\Catering;
use App\Decorator;
use App\FarmHouse;
use App\HotelRestaurant;
use App\LawnBanquet;
use App\Photographer;
use App\Transport;

class TransactionController extends Controller
{
    private $TransactionRepository;

    public function __construct(TransactionRepository $TransactionRepository)
    {
        $this->middleware('auth:api');
        $this->TransactionRepository = $TransactionRepository;
    }

    public function index(Request $request)
    {
        if(Gate::allows('view-transaction')){
            $Transactions = $this->TransactionRepository->index($request);
            return $Transactions;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function store(TransactionValidation $request)
    {
        if(Gate::allows('create-transaction')){
            $validated = $request->validated();
            $request['user_id'] = auth()->user()->id;
            if($request->hut_id){
                $vendor = Hut::find($request->hut_id);
            }
            if($request->catering_id){
                $vendor = Catering::find($request->catering_id);
            }
            if($request->decorator_id){
                $vendor = Decorator::find($request->decorator_id);
            }
            if($request->farmhouse_id){
                $vendor = FarmHouse::find($request->farmhouse_id);
            }
            if($request->hotelrestaurant_id){
                $vendor = HotelRestaurant::find($request->hotelrestaurant_id);
            }
            if($request->lawnbanquet_id){
                $vendor = LawnBanquet::find($request->lawnbanquet_id);
            }
            if($request->photographer_id){
                $vendor = Photographer::find($request->photographer_id);
            }
            if($request->transport_id){
                $vendor = Transport::find($request->transport_id);
            }
            if(empty($vendor)){
                return response()->json(['error'=>'invalid venue id']);
            }
            $request['vendor_id'] = $vendor->vendor_id;
            $Transactions = $this->TransactionRepository->store($request);
            return $Transactions;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function show($id)
    {
        $Transaction = $this->TransactionRepository->find($id);
        return response()->json($Transaction);
    }

    public function update(TransactionValidation $request, $id)
    {
        if(Gate::allows('update-transaction')){
            $validated = $request->validated();
            $Transactions = $this->TransactionRepository->update($request,$id);
            return $Transactions;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function destroy($id)
    {
        if(Gate::allows('delete-transaction')){
            $Transactions = $this->TransactionRepository->destroy($id);
            return $Transactions;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function search(Request $request)
    {
        $Transactions = $this->TransactionRepository->search($request);
        return $Transactions;
    }

    public function date_search(Request $request)
    {
        $Transactions = $this->TransactionRepository->date_search($request);
        return $Transactions;
    }

    public function week_earnings(){
        return $this->TransactionRepository->week_earnings();
    }

    public function month_earnings(){
        return $this->TransactionRepository->month_earnings();
    }

    public function add_to_featured(Request $request){
        return $this->TransactionRepository->add_to_featured($request);
    }
}
