<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repository\VideoAnimationRepository;
use App\Http\Requests\VideoAnimationValidation;
use Illuminate\Support\Facades\Gate;

class VideoAnimCon extends Controller
{
    private $VideoAnimationRepository;

    public function __construct(VideoAnimationRepository $VideoAnimationRepository)
    {
        $this->middleware('auth:api');
        $this->VideoAnimationRepository = $VideoAnimationRepository;
    }

    public function list(Request $request){
        return $this->VideoAnimationRepository->list($request);
    }

    public function popular(Request $request)
    {
        return $this->VideoAnimationRepository->popular($request);
    }

    public function featured(Request $request)
    {
        return $this->VideoAnimationRepository->featured($request);
    }

    public function index(Request $request)
    {
        if(Gate::allows('view-video_animations')){
            $VideoAnimation = $this->VideoAnimationRepository->index($request);
            return $VideoAnimation;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function store(VideoAnimationValidation $request)
    {
        if(Gate::allows('create-video_animations')){
            $validated = $request->validated();
            if($request->image_type){
                $request['image'] = $this->VideoAnimationRepository->storeImage($request);
            }
            if(!$request->vendor_id){
                $request['vendor_id'] = auth()->user()->id;
            }
            if(is_array($request['facilities'])){
                $request['facilities'] = implode(',',$request['facilities']);
            }
            $VideoAnimation = $this->VideoAnimationRepository->store($request);
            return $VideoAnimation;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function show($id)
    {
        $VideoAnimation = $this->VideoAnimationRepository->get_video_animations($id);
        return response()->json($VideoAnimation);
    }

    public function update(VideoAnimationValidation $request, $id)
    {
        if(Gate::allows('update-video_animations')){
            $validated = $request->validated();
            $VideoAnimation = $this->VideoAnimationRepository->update($request,$id);
            return $VideoAnimation;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function destroy($id)
    {
        if(Gate::allows('delete-video_animations')){
            $VideoAnimation = $this->VideoAnimationRepository->destroy($id);
            return $VideoAnimation;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function search(Request $request)
    {
        $VideoAnimation = $this->VideoAnimationRepository->search($request);
        return $VideoAnimation;
    }

    public function date_search(Request $request)
    {
        $VideoAnimation = $this->VideoAnimationRepository->date_search($request);
        return $VideoAnimation;
    }
}
