<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class UploadController extends Controller
{
    public function file_upload(Request $request){
    	if($request->hasFile('image')){
    		$file = $request->file('image');
    		$filename = $request->fileId.'.'.$request->file('image')->extension();
    		$file->storeAs('public',$filename);
    		return 'storage/'.$filename;
    	}
    	return 'File Uploaded';
    }

    public function file_delete(Request $request){
		Storage::delete('public/'.$request->fileId.'.jpg');
		Storage::delete('public/'.$request->fileId.'.png');
    }
}
