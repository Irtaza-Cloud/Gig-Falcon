<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Hut;
use App\Catering;
use App\Decorator;
use App\FarmHouse;
use App\HotelRestaurant;
use App\LawnBanquet;
use App\Photographer;
use App\Transport;
use App\Repository\ReviewRepository;

class ReviewController extends Controller
{
    private $ReviewRepository;

    public function __construct(ReviewRepository $ReviewRepository)
    {
        $this->middleware('auth:api');
        $this->ReviewRepository = $ReviewRepository;
    }

    public function index(Request $request)
    {
        $Reviews = $this->ReviewRepository->index($request);
        return $Reviews;
    }

    public function store(Request $request)
    {
        $request['sender_id'] = auth()->user()->id;
        if($request->hut_id){
            $vendor = Hut::find($request->hut_id);
        }
        if($request->catering_id){
            $vendor = Catering::find($request->catering_id);
        }
        if($request->decorator_id){
            $vendor = Decorator::find($request->decorator_id);
        }
        if($request->farmhouse_id){
            $vendor = FarmHouse::find($request->farmhouse_id);
        }
        if($request->hotelrestaurant_id){
            $vendor = HotelRestaurant::find($request->hotelrestaurant_id);
        }
        if($request->lawnbanquet_id){
            $vendor = LawnBanquet::find($request->lawnbanquet_id);
        }
        if($request->photographer_id){
            $vendor = Photographer::find($request->photographer_id);
        }
        if($request->transport_id){
            $vendor = Transport::find($request->transport_id);
        }
        if(empty($vendor)){
            return response()->json(['error'=>'invalid venue id']);
        }
        $request['receiver_id'] = $vendor->vendor_id;
        $Reviews = $this->ReviewRepository->store($request);
        return $Reviews;
    }

    public function show($id)
    {
        $Review = $this->ReviewRepository->find($id);
        return response()->json($Review);
    }

    public function destroy($id)
    {
        $Reviews = $this->ReviewRepository->destroy($id);
        return $Reviews;
    }

    public function like_review(Request $request){
        return $this->ReviewRepository->like_review($request);
    }

    public function review_reply(Request $request){
        return $this->ReviewRepository->review_reply($request);
    }

    public function vendor_reviews(){
        return $this->ReviewRepository->vendor_reviews();
    }
}
