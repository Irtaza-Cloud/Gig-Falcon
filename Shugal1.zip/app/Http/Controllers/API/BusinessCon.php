<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repository\BusinessRepository;
use App\Http\Requests\BusinessValidation;
use Illuminate\Support\Facades\Gate;

class BusinessCon extends Controller
{
    private $BusinessRepository;

    public function __construct(BusinessRepository $BusinessRepository)
    {
        $this->middleware('auth:api');
        $this->BusinessRepository = $BusinessRepository;
    }

    public function list(Request $request){
        return $this->BusinessRepository->list($request);
    }

    public function popular(Request $request)
    {
        return $this->BusinessRepository->popular($request);
    }

    public function featured(Request $request)
    {
        return $this->BusinessRepository->featured($request);
    }

    public function index(Request $request)
    {
        if(Gate::allows('view-businesses')){
            $Business = $this->BusinessRepository->index($request);
            return $Business;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function store(BusinessValidation $request)
    {
        if(Gate::allows('create-businesses')){
            $validated = $request->validated();
            if($request->image_type){
                $request['image'] = $this->BusinessRepository->storeImage($request);
            }
            if(!$request->vendor_id){
                $request['vendor_id'] = auth()->user()->id;
            }
            if(is_array($request['decor_packages'])){
                $request['decor_packages'] = implode(',',$request['decor_packages']);
            }
            $Business = $this->BusinessRepository->store($request);
            return $Business;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function show($id)
    {
        $Business = $this->BusinessRepository->get_businesses($id);
        return response()->json($Business);
    }

    public function update(BusinessValidation $request, $id)
    {
        if(Gate::allows('update-businesses')){
            $validated = $request->validated();
            $Business = $this->BusinessRepository->update($request,$id);
            return $Business;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function destroy($id)
    {
        if(Gate::allows('delete-businesses')){
            $Business = $this->BusinessRepository->destroy($id);
            return $Business;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function search(Request $request)
    {
        $Business = $this->BusinessRepository->search($request);
        return $Business;
    }

    public function date_search(Request $request)
    {
        $Business = $this->BusinessRepository->date_search($request);
        return $Business;
    }
}
