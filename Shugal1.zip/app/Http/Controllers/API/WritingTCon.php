<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repository\WritingTranslationRepository;
use App\Http\Requests\WritingandTranslationValidation;
use Illuminate\Support\Facades\Gate;

class WritingTCon extends Controller
{
    private $WritingTranslationRepository;

    public function __construct(WritingTranslationRepository $WritingTranslationRepository)
    {
        $this->middleware('auth:api');
        $this->WritingTranslationRepository = $WritingTranslationRepository;
    }

    public function list(Request $request){
        return $this->WritingTranslationRepository->list($request);
    }

    public function popular(Request $request)
    {
        return $this->WritingTranslationRepository->popular($request);
    }

    public function featured(Request $request)
    {
        return $this->WritingTranslationRepository->featured($request);
    }

    public function index(Request $request)
    {
        if(Gate::allows('view-decorator')){
            $WritingTranslation = $this->WritingTranslationRepository->index($request);
            return $WritingTranslation;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function store(WritingandTranslationValidation $request)
    {
        if(Gate::allows('create-decorator')){
            $validated = $request->validated();
            if($request->image_type){
                $request['image'] = $this->WritingTranslationRepository->storeImage($request);
            }
            if(!$request->vendor_id){
                $request['vendor_id'] = auth()->user()->id;
            }
            if(is_array($request['specialities'])){
                $request['specialities'] = implode(',',$request['specialities']);
            }
            $WritingTranslation = $this->WritingTranslationRepository->store($request);
            return $WritingTranslation;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function show($id)
    {
        $WritingTranslation = $this->WritingTranslationRepository->get_writing_translations($id);
        return response()->json($WritingTranslation);
    }

    public function update(WritingandTranslationValidation $request, $id)
    {
        if(Gate::allows('update-decorator')){
            $validated = $request->validated();
            $WritingTranslation = $this->WritingTranslationRepository->update($request,$id);
            return $WritingTranslation;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function destroy($id)
    {
        if(Gate::allows('delete-decorator')){
            $WritingTranslation = $this->WritingTranslationRepository->destroy($id);
            return $WritingTranslation;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function search(Request $request)
    {
        $WritingTranslation = $this->WritingTranslationRepository->search($request);
        return $WritingTranslation;
    }

    public function date_search(Request $request)
    {
        $WritingTranslation = $this->WritingTranslationRepository->date_search($request);
        return $WritingTranslation;
    }
}
