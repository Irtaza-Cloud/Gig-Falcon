<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repository\FunandLifestyleRepository;
use App\Http\Requests\FunandLifestyleValidation;
use Illuminate\Support\Facades\Gate;

class FunLifestyleCon extends Controller
{
    private $FunandLifestyleRepository;

    public function __construct(FunandLifestyleRepository $FunandLifestyleRepository)
    {
        $this->middleware('auth:api');
        $this->FunandLifestyleRepository = $FunandLifestyleRepository;
    }

    public function list(Request $request){
        return $this->FunandLifestyleRepository->list($request);
    }

    public function popular(Request $request)
    {
        return $this->FunandLifestyleRepository->popular($request);
    }

    public function featured(Request $request)
    {
        return $this->FunandLifestyleRepository->featured($request);
    }

    public function index(Request $request)
    {
        if(Gate::allows('view-fun_lifestyles')){
            $FunandLifestyle = $this->FunandLifestyleRepository->index($request);
            return $FunandLifestyle;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function store(FunandLifestyleValidation $request)
    {
        if(Gate::allows('create-fun_lifestyles')){
            $validated = $request->validated();
            if($request->image_type){
                $request['image'] = $this->FunandLifestyleRepository->storeImage($request);
            }
            if(!$request->vendor_id){
                $request['vendor_id'] = auth()->user()->id;
            }
            if(is_array($request['specialities'])){
                $request['specialities'] = implode(',',$request['specialities']);
            }
            $FunandLifestyle = $this->FunandLifestyleRepository->store($request);
            return $FunandLifestyle;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function show($id)
    {
        $FunandLifestyle = $this->FunandLifestyleRepository->get_fun_lifestyles($id);
        return response()->json($FunandLifestyle);
    }

    public function update(FunandLifestyleValidation $request, $id)
    {
        if(Gate::allows('update-fun_lifestyles')){
            $validated = $request->validated();
            $FunandLifestyle = $this->FunandLifestyleRepository->update($request,$id);
            return $FunandLifestyle;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function destroy($id)
    {
        if(Gate::allows('delete-fun_lifestyles')){
            $FunandLifestyle = $this->FunandLifestyleRepository->destroy($id);
            return $FunandLifestyle;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function search(Request $request)
    {
        $FunandLifestyle = $this->FunandLifestyleRepository->search($request);
        return $FunandLifestyle;
    }

    public function date_search(Request $request)
    {
        $FunandLifestyle = $this->FunandLifestyleRepository->date_search($request);
        return $FunandLifestyle;
    }
}
