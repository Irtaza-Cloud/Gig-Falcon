<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repository\ProgrammingTechRepository;
use App\Http\Requests\ProgrammingTechValidation;
use Illuminate\Support\Facades\Gate;

class ProgrammingTechCon extends Controller
{
    private $ProgrammingTechRepository;

    public function __construct(ProgrammingTechRepository $ProgrammingTechRepository)
    {
        $this->middleware('auth:api');
        $this->ProgrammingTechRepository = $ProgrammingTechRepository;
    }

    public function list(Request $request){
        return $this->ProgrammingTechRepository->list($request);
    }

    public function popular(Request $request)
    {
        return $this->ProgrammingTechRepository->popular($request);
    }

    public function featured(Request $request)
    {
        return $this->ProgrammingTechRepository->featured($request);
    }

    public function index(Request $request)
    {
        if(Gate::allows('view-hotelrestaurant')){
            $ProgrammingTech = $this->ProgrammingTechRepository->index($request);
            return $ProgrammingTech;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function store(ProgrammingTechValidation $request)
    {
        if(Gate::allows('create-hotelrestaurant')){
            $validated = $request->validated();
            if($request->image_type){
                $request['image'] = $this->ProgrammingTechRepository->storeImage($request);
            }
            if(!$request->vendor_id){
                $request['vendor_id'] = auth()->user()->id;
            }
            if(is_array($request['decor_packages'])){
                $request['decor_packages'] = implode(',',$request['decor_packages']);
            }
            $ProgrammingTech = $this->ProgrammingTechRepository->store($request);
            return $ProgrammingTech;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function show($id)
    {
        $ProgrammingTech = $this->ProgrammingTechRepository->get_programming_tech($id);
        return response()->json($ProgrammingTech);
    }

    public function update(ProgrammingTechValidation $request, $id)
    {
        if(Gate::allows('update-hotelrestaurant')){
            $validated = $request->validated();
            $ProgrammingTech = $this->ProgrammingTechRepository->update($request,$id);
            return $ProgrammingTech;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function destroy($id)
    {
        if(Gate::allows('delete-hotelrestaurant')){
            $ProgrammingTech = $this->ProgrammingTechRepository->destroy($id);
            return $ProgrammingTech;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function search(Request $request)
    {
        $ProgrammingTech = $this->ProgrammingTechRepository->search($request);
        return $ProgrammingTech;
    }

    public function date_search(Request $request)
    {
        $ProgrammingTech = $this->ProgrammingTechRepository->date_search($request);
        return $ProgrammingTech;
    }
}
