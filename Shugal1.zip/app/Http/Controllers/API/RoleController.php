<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repository\RoleRepository;
use App\Http\Requests\RoleValidation;
use Illuminate\Support\Facades\Gate;

class RoleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct(RoleRepository $roleRepository)
    {
        $this->middleware('auth:api');
        $this->roleRepository = $roleRepository;
    }

    public function index(Request $request)
    {
        if(Gate::allows('view-role')){
            $roles = $this->roleRepository->index($request);
            return $roles;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(RoleValidation $request)
    {
        if(Gate::allows('create-role')){
            $validated = $request->validated();
            $roles = $this->roleRepository->storeRole($request);
            return $roles;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(RoleValidation $request, $id)
    {
        if(Gate::allows('update-role')){
            $validated = $request->validated();
            $roles = $this->roleRepository->updateRole($request,$id);
            return $roles;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if(Gate::allows('delete-role')){
            $roles = $this->roleRepository->destroy($id);
            return $roles;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function date_search(Request $request)
    {
        $roles = $this->roleRepository->date_search($request);
        return $roles;
    }
}
