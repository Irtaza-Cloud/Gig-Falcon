<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repository\GraphicDesignRepository;
use App\Http\Requests\GraphicDesignValidation;
use Illuminate\Support\Facades\Gate;
use App\GraphicDesign;

class GraphicDesignCon extends Controller
{
    private $GraphicDesignRepository;

    public function __construct(GraphicDesignRepository $graphicdesignRepository)
    {
        $this->middleware('auth:api');
        $this->GraphicDesignRepository = $graphicdesignRepository;
    }

    public function list(Request $request){
        return $this->GraphicDesignRepository->list($request);
    }

    public function popular(Request $request)
    {
        return $this->GraphicDesignRepository->popular($request);
    }

    public function featured(Request $request)
    {
        return $this->GraphicDesignRepository->featured($request);
    }

    public function index(Request $request)
    {
        if(Gate::allows('view-graphicdesign')){
            $GraphicDesign = $this->GraphicDesignRepository->index($request);
            return $GraphicDesign;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function store(GraphicDesignValidation $request)
    {
        if(Gate::allows('create-graphicdesign')){
            $validated = $request->validated();
            if($request->image_type){
                $request['image'] = $this->GraphicDesignRepository->storeImage($request);
            }
            if(!$request->vendor_id){
                $request['vendor_id'] = auth()->user()->id;
            }
            if(is_array($request['facilities'])){
                $request['facilities'] = implode(',',$request['facilities']);
            }
            $GraphicDesign = $this->GraphicDesignRepository->store($request);
            return $GraphicDesign;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function show($id)
    {
        $GraphicDesign = $this->GraphicDesignRepository->get_graphic_designings($id);
        return response()->json($GraphicDesign);
    }

    public function update(GraphicDesignValidation $request, $id)
    {
        if(Gate::allows('update-graphicdesign')){
            $validated = $request->validated();
            $GraphicDesign = $this->GraphicDesignRepository->update($request,$id);
            return $GraphicDesign;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function destroy($id)
    {
        if(Gate::allows('delete-graphicdesign')){
            $GraphicDesign = $this->GraphicDesignRepository->destroy($id);
            return $GraphicDesign;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function search(Request $request)
    {
        $GraphicDesign = $this->GraphicDesignRepository->search($request);
        return $GraphicDesign;
    }

    public function date_search(Request $request)
    {
        $GraphicDesign = $this->GraphicDesignRepository->date_search($request);
        return $GraphicDesign;
    }
}
