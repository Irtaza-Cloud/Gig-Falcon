<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Repository\BookingRepository;
use App\Http\Requests\BookingValidation;
use Illuminate\Support\Facades\Gate;
use Carbon\Carbon;
use App\GraphicDesign;
use App\DigitalMarketing;
use App\WritingTranslation;
use App\VideoAnimation;
use App\ProgrammingTech;
use App\Business;
use App\FunLifestyle;
use App\MusicsAudio;

class BookingController extends Controller
{
    private $BookingRepository;

    public function __construct(BookingRepository $BookingRepository)
    {
        $this->middleware('auth:api');
        $this->BookingRepository = $BookingRepository;
    }

    public function index(Request $request)
    {
        if(Gate::allows('view-booking')){
            $Bookings = $this->BookingRepository->index($request);
            return $Bookings;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function store(BookingValidation $request)
    {
        if(Gate::allows('create-booking')){
            $validated = $request->validated();
            $request['booking_date'] = Carbon::parse($request['booking_date'])->format('Y-m-d');
            $request['user_id'] = auth()->user()->id;
            if($request->	graphic_designings_id){
                $vendor = GraphicDesign::find($request->graphic_designings_id);
            }
            if($request->digital_marketings_id){
                $vendor = DigitalMarketing::find($request->digital_marketings_id);
            }
            if($request->	writing_translations_id){
                $vendor = WritingTranslation::find($request->	writing_translations_id);
            }
            if($request->video_animations_id){
                $vendor = VideoAnimation::find($request->video_animations_id);
            }
            if($request->	programming_tech_id){
                $vendor = ProgrammingTech::find($request->	programming_tech_id);
            }
            if($request->	businesses_id){
                $vendor = Business::find($request->	businesses_id);
            }
            if($request->fun_lifestyles_id){
                $vendor = FunLifestyle::find($request->fun_lifestyles_id);
            }
            if($request->music_audios_id){
                $vendor = MusicsAudio::find($request->music_audios_id);
            }
            $request['vendor_id'] = $vendor->vendor_id;
            $Bookings = $this->BookingRepository->store($request);
            return $Bookings;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function show($id)
    {
        $Booking = $this->BookingRepository->find($id);
        return response()->json($Booking);
    }

    public function update(BookingValidation $request, $id)
    {
        if(Gate::allows('update-booking')){
            $validated = $request->validated();
            $Bookings = $this->BookingRepository->update($request,$id);
            return $Bookings;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function destroy($id)
    {
        if(Gate::allows('delete-booking')){
            $Bookings = $this->BookingRepository->destroy($id);
            return $Bookings;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function search(Request $request)
    {
        $Bookings = $this->BookingRepository->search($request);
        return $Bookings;
    }

    public function date_search(Request $request)
    {
        $Bookings = $this->BookingRepository->date_search($request);
        return $Bookings;
    }

    public function check_availability(Request $request){
        return $this->BookingRepository->check_availability($request);
    }

    public function get_data(){
        return $this->BookingRepository->get_data();
    }

    public function confirm_booking(Request $request){
        return $this->BookingRepository->confirm_booking($request);
    }

    public function confirm_all(Request $request){
        return $this->BookingRepository->confirm_all($request);
    }

    public function today_bookings(){
        return $this->BookingRepository->today_bookings();
    }

    public function upcoming_bookings(){
        return $this->BookingRepository->upcoming_bookings();
    }

    public function cancel_booking(Request $request){
        return $this->BookingRepository->cancel_booking($request);
    }
}
