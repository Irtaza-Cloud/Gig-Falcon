<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repository\RatingRepository;
use App\Http\Requests\RatingValidation;
use Illuminate\Support\Facades\Gate;

class RatingController extends Controller
{
    private $RatingRepository;

    public function __construct(RatingRepository $RatingRepository)
    {
        $this->middleware('auth:api');
        $this->RatingRepository = $RatingRepository;
    }

    public function index(Request $request)
    {
        if(Gate::allows('view-rating')){
            $Ratings = $this->RatingRepository->index($request);
            return $Ratings;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function store(RatingValidation $request)
    {
        if(Gate::allows('create-rating')){
            $validated = $request->validated();
            $request['user_id'] = auth()->user()->id;
            $Ratings = $this->RatingRepository->store($request);
            $this->RatingRepository->update_table_rating($request);
            return $Ratings;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function show($id)
    {
        $Rating = $this->RatingRepository->find($id);
        return response()->json($Rating);
    }

    public function update(RatingValidation $request, $id)
    {
        if(Gate::allows('update-rating')){
            $validated = $request->validated();
            $Ratings = $this->RatingRepository->update($request,$id);
            return $Ratings;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function destroy($id)
    {
        if(Gate::allows('delete-rating')){
            $Ratings = $this->RatingRepository->destroy($id);
            return $Ratings;
        }
        return response()->json(['error'=>'Access Denied You Donot Have Permission'],403);
    }

    public function search(Request $request)
    {
        $Ratings = $this->RatingRepository->search($request);
        return $Ratings;
    }

    public function date_search(Request $request)
    {
        $Ratings = $this->RatingRepository->date_search($request);
        return $Ratings;
    }

}
