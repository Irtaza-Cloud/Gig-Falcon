<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DigitalMarketing extends Model
{
    protected $fillable = [
        'name','image','address','description','service_hours','seating_capacity','specialities','minimum_servings','charge_per_person','rent_per_day','contact','rating','vendor_id','featured_duration'
    ];
}
