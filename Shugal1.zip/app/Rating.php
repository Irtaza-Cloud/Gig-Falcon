<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rating extends Model
{
    protected $with = ['user','hut'];
    
    protected $fillable = [
        'user_id','hut_id','catering_id','decorator_id','transport_id','photographer_id','farm_house_id','hotel_restaurant_id','lawn_banquet_id','rating'
    ];

    public function user(){
        return $this->belongsTo('App\User');
    }

    public function hut(){
        return $this->belongsTo('App\Hut');
    }

    public function catering(){
        return $this->belongsTo('App\Catering');
    }

    public function decorator(){
        return $this->belongsTo('App\Decorator');
    }

    public function photographer(){
        return $this->belongsTo('App\Photographer');
    }

    public function transport(){
        return $this->belongsTo('App\Transport');
    }

    public function farm_house(){
        return $this->belongsTo('App\FarmHouse');
    }

    public function hotel_restaurant(){
        return $this->belongsTo('App\HotelRestaurant');
    }

    public function lawn_banquet(){
        return $this->belongsTo('App\LawnBanquet');
    }
}
