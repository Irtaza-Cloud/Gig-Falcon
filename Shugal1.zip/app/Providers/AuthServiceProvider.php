<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;
use Laravel\Passport\Passport;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        // 'App\Model' => 'App\Policies\ModelPolicy',
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();
        Passport::routes();

        Gate::define('view-user',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->view_user);
        });

        Gate::define('create-user',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->create_user);
        });

        Gate::define('update-user',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->update_user);
        });

        Gate::define('delete-user',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->delete_user);
        });

        Gate::define('view-hut',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->view_hut);
        });

        Gate::define('create-hut',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->create_hut);
        });

        Gate::define('update-hut',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->update_hut);
        });

        Gate::define('delete-hut',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->delete_hut);
        });

        Gate::define('view-farmhouse',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->view_farmhouse);
        });

        Gate::define('create-farmhouse',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->create_farmhouse);
        });

        Gate::define('update-farmhouse',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->update_farmhouse);
        });

        Gate::define('delete-farmhouse',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->delete_farmhouse);
        });

        Gate::define('view-catering',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->view_catering);
        });

        Gate::define('create-catering',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->create_catering);
        });

        Gate::define('update-catering',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->update_catering);
        });

        Gate::define('delete-catering',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->delete_catering);
        });

        Gate::define('view-decorator',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->view_decorator);
        });

        Gate::define('create-decorator',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->create_decorator);
        });

        Gate::define('update-decorator',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->update_decorator);
        });

        Gate::define('delete-decorator',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->delete_decorator);
        });

        Gate::define('view-photographer',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->view_photographer);
        });

        Gate::define('create-photographer',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->create_photographer);
        });

        Gate::define('update-photographer',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->update_photographer);
        });

        Gate::define('delete-photographer',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->delete_photographer);
        });

        Gate::define('view-hotelrestaurant',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->view_hotelrestaurant);
        });

        Gate::define('create-hotelrestaurant',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->create_hotelrestaurant);
        });

        Gate::define('update-hotelrestaurant',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->update_hotelrestaurant);
        });

        Gate::define('delete-hotelrestaurant',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->delete_hotelrestaurant);
        });

        Gate::define('view-lawnbanquet',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->view_lawnbanquet);
        });

        Gate::define('create-lawnbanquet',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->create_lawnbanquet);
        });

        Gate::define('update-lawnbanquet',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->update_lawnbanquet);
        });

        Gate::define('delete-lawnbanquet',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->delete_lawnbanquet);
        });

        Gate::define('view-transport',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->view_transport);
        });

        Gate::define('create-transport',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->create_transport);
        });

        Gate::define('update-transport',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->update_transport);
        });

        Gate::define('delete-transport',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->delete_transport);
        });

        Gate::define('view-transaction',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->view_transaction);
        });

        Gate::define('view-booking',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->view_booking);
        });

        Gate::define('create-booking',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->create_booking);
        });

        Gate::define('update-booking',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->update_booking);
        });

        Gate::define('delete-booking',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->delete_booking);
        });

        Gate::define('view-rating',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->view_rating);
        });

        Gate::define('create-rating',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->create_rating);
        });

        Gate::define('update-rating',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->update_rating);
        });

        Gate::define('delete-rating',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->delete_rating);
        });

        Gate::define('view-checkinout',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->view_checkinout);
        });

        Gate::define('create-checkinout',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->create_checkinout);
        });

        Gate::define('update-checkinout',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->update_checkinout);
        });

        Gate::define('delete-checkinout',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->delete_checkinout);
        });

        Gate::define('view-role',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->view_role);
        });

        Gate::define('create-role',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->create_role);
        });

        Gate::define('update-role',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->update_role);
        });

        Gate::define('delete-role',function($user){
            $permissions = json_decode($user->roles[0]->permissions);
            return isset($permissions->delete_role);
        });

        //
    }
}
