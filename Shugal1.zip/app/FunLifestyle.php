<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FunLifestyle extends Model
{
    protected $fillable = [
        'name','image','address','description','service_hours','equipments','specialities','slots','rent_per_slot','contact','rating','vendor_id','featured_duration'
    ];
}
