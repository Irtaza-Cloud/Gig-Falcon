<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    protected $with = [
        'user','graphic_designings','digital_marketings','writing_translations','video_animations','programming_tech','businesses','fun_lifestyles','music_audios'
    ];

    protected $fillable = [
        'graphic_designings_id','digital_marketings_id','writing_translations_id','video_animations_id','programming_tech_id','businesses_id','fun_lifestyles_id','muic_audios_id','user_id','booking_date','time_slot','status','vendor_id','amount'
    ];

    public function user(){
        return $this->belongsTo('App\User','user_id');
    }

    public function graphic_designings(){
        return $this->belongsTo('App\graphic_designings','graphic_designings_id');
    }

    public function digital_marketings(){
        return $this->belongsTo('App\digital_marketings','digital_marketings_id');
    }

    public function writing_translations(){
        return $this->belongsTo('App\writing_translations','writing_translations_id');
    }

    public function video_animations(){
        return $this->belongsTo('App\video_animations','video_animations_id');
    }

    public function programming_tech(){
        return $this->belongsTo('App\programming_tech','programming_tech_id');
    }

    public function businesses(){
        return $this->belongsTo('App\businesses','businesses_id');
    }

    public function fun_lifestyles(){
        return $this->belongsTo('App\fun_lifestyles','fun_lifestyles_id');
    }

    public function music_audios(){
        return $this->belongsTo('App\music_audios','music_audios_id');
    }
}
