<?php
    error_reporting(0);
?>


<?php $__env->startSection('content'); ?>



<div class="row justify-content-center">
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12" style="">
                <div class="card" >
                    <div class="card-body">
                        <h4>Profile Page</h4>
                        <hr>
                        <form method="POST" action="/profile">
                            <?php echo csrf_field(); ?>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
    <label for="">Name</label>
    <input type="text" value="<?php echo e(Auth::user()->username); ?>" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
    <label for="">Email</label>
    <input type="text" value="<?php echo e(Auth::user()->email); ?>" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
    <label for="">Password</label>
    <input type="text" value="<?php echo e(Auth::user()->password); ?>" class="form-control">
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="">Image</label>
                                        <img src="<?php echo e(asset('img/'.Auth::user()->image)); ?>" class="pic">
                                    </div>
                                </div>

                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-success">
                                        <?php echo e(__('Update')); ?>

                                    </button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
    </section>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PHP\Xampp\htdocs\Shugal\resources\views/profile.blade.php ENDPATH**/ ?>